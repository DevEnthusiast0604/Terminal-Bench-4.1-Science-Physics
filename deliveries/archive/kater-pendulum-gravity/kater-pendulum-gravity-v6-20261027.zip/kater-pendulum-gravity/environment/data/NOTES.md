# Kater pendulum, release runs

A rigid steel bar carries two knife-edge pivots, A and B, facing each other, and a movable
mass. The bar was hung on one knife edge at a time and released from rest at a chosen angle.
Runs a1, a2, a3 hang on edge A; runs b1, b2, b3 hang on edge B. Release amplitudes differ
from run to run. A camera filmed each swing and a tracker logged the bar angle per frame.

## Geometry (measured, SI units)

These two lengths were measured once and apply to every run.

    knife_edge_separation_m = 1.00003
    centre_of_mass_from_edge_a_m = 0.20011

The centre of mass lies between the two edges, on the line joining them. The first value is the
distance between the edges; the second is the distance from edge A to the centre of mass, found
by balancing the bar on a third edge.

## Files

    runs/<run>.csv    tracker log, one row per frame the tracker received
    sync/<run>.csv    camera clock check for the same run

### runs/<run>.csv

Leading lines that start with `#` are metadata: `unit` is the angle unit used in this file and
`nominal_fps` is the frame rate the camera is set to. Then a header row and one row per frame:

    frame_counter   the camera's hardware frame counter, 16 bits, counting each frame delivered
                    to the tracker; no time stamps are recorded
    theta           bar angle from the image vertical, in the unit named in the header
    tracker_ok      1 when the tracker found the bar in that frame; 0 when it lost the bar, in
                    which case theta repeats the last good value

The image vertical is not exactly the plumb line (the camera is slightly rolled), so theta is
zero at some small unknown angle away from the bar's rest position.

### sync/<run>.csv

The camera's own oscillator is free-running and is not locked to anything. To check it, an LED
in the camera's view is switched on by a GPS-disciplined pulse at the start of every GPS second.
`gps_s` is the whole GPS second and `frame_counter` is the counter value of the first frame in
which the LED was seen lit. The detector occasionally misses a second; those rows are absent.

## Damping

The bar loses amplitude slowly through air drag and pivot friction; both are small.
