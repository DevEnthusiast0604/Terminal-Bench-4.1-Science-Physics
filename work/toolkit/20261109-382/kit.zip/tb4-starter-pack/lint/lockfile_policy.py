#!/usr/bin/env python3
"""Lockfile policy for build-time dependency installs (Terminal-Bench 4.1 check-lockfiles).

Ported from harbor-framework/terminal-bench v4.1.0 scripts/checks/check-lockfiles.py
(commit 4070d6cef56a7d20cb5dc98d5e10ada88a6b9440, Apache-2.0). The Checker is the upstream code;
two changes only: PyYAML is optional (without it, compose build contexts and pnpm-lock.yaml are not
traced), and findings() returns (path, line, message) for tb4-lint instead of printing.

Upstream's notes: tracks local COPY, WORKDIR, cd, and direct shell-script calls. This is deliberately
not a shell interpreter: unresolved dependency paths are errors, not exemptions.
"""


import fnmatch
import json
import posixpath
import re
import shlex
import sys
import tomllib
from pathlib import Path

try:
    import yaml
except ImportError:  # optional: compose contexts and pnpm-lock.yaml need it
    yaml = None


YAML_ERRORS = (yaml.YAMLError,) if yaml else ()


def ignore_match(path, pattern):
    # Docker's * is segment-local; **/ can also match zero directories.
    def match(parts, patterns):
        if not patterns:
            return not parts
        if patterns[0] == "**":
            return match(parts, patterns[1:]) or bool(parts) and match(parts[1:], patterns)
        return bool(parts) and fnmatch.fnmatchcase(parts[0], patterns[0]) and match(parts[1:], patterns[1:])

    return match(path.split("/"), pattern.split("/"))


def absolute(value, cwd):
    return posixpath.normpath(posixpath.join(cwd, value))


def option(words, *names):
    for i, word in enumerate(words):
        for name in names:
            if word == name and i + 1 < len(words):
                return words[i + 1]
            if word.startswith(name + "="):
                return word.split("=", 1)[1]
    return None


def instructions(text):
    start, pending = 0, ""
    lines = iter(enumerate(text.splitlines(), 1))
    for number, line in lines:
        if not pending and (not line.strip() or line.lstrip().startswith("#")):
            continue
        if not pending:
            start = number
        pending += line.rstrip().removesuffix("\\") + " "
        if line.rstrip().endswith("\\"):
            continue
        instruction = pending.strip()
        pending = ""
        if re.search(r"^RUN\b.*<<-?['\"]?[A-Za-z_]", instruction, re.I):
            marker = re.search(r"<<-?['\"]?([A-Za-z_]\w*)['\"]?(?:\s+(?:bash|sh))?$", instruction)
            if not marker:
                yield start, "RUN __UNSUPPORTED_HEREDOC__"
                continue
            body = []
            for _, heredoc_line in lines:
                if heredoc_line.strip() == marker.group(1):
                    yield start, instruction + "\n" + "\n".join(body)
                    break
                body.append(heredoc_line)
            else:
                yield start, "RUN __UNTERMINATED_HEREDOC__"
        else:
            yield start, instruction
    if pending:
        yield start, pending.strip()


class Checker:
    def __init__(self, dockerfile, context):
        self.dockerfile, self.context = dockerfile, context.resolve()
        self.files, self.stages, self.env = {}, {}, {}
        self.cwd = "/"
        self.errors = []
        specific = dockerfile.with_name(dockerfile.name + ".dockerignore")
        ignore = specific if specific.exists() else context / ".dockerignore"
        self.ignores = []
        if ignore.exists():
            if not ignore.resolve().is_relative_to(self.context):
                self.fail(ignore, "ignore file must stay inside the build context")
            else:
                self.ignores = ignore.read_text().splitlines()

    def fail(self, location, message):
        self.errors.append(f"FAIL {location}: {message}")

    def included(self, path):
        if not path.resolve().is_relative_to(self.context):
            return False
        relative = path.relative_to(self.context).as_posix()
        ignored = False
        for raw in self.ignores:
            pattern = raw.strip()
            if not pattern or pattern.startswith("#"):
                continue
            negate = pattern.startswith("!")
            pattern = pattern.lstrip("!").strip("/")
            parts = relative.split("/")
            candidates = ["/".join(parts[:i]) for i in range(1, len(parts) + 1)]
            if any(ignore_match(p, pattern) for p in candidates):
                ignored = not negate
        return not ignored

    def expand(self, value, variables):
        values = [value.replace("$(uname -m)", arch) for arch in ("x86_64", "aarch64")] if "$(uname -m)" in value else [value]
        for name in re.findall(r"\$\{?(\w+)\}?", value):
            replacements = variables.get(name, self.env.get(name, []))
            if not replacements:
                return []
            values = [re.sub(r"\$\{" + name + r"\}|\$" + name + r"\b", replacement, v) for v in values for replacement in replacements]
        return values

    def copy(self, body, location):
        source_stage = re.search(r"--from=(\S+)", body)
        body = re.sub(r"--[\w-]+=(?:\"[^\"]*\"|\S+)\s*", "", body)
        words = json.loads(body) if body.startswith("[") else shlex.split(body)
        if len(words) < 2:
            self.fail(location, "cannot trace COPY operands")
            return
        destination = absolute(words[-1], self.cwd)
        directory = words[-1].endswith("/") or len(words) > 2 or words[-1] in (".", "..")
        for source in words[:-1]:
            if source_stage:
                stage = self.stages.get(source_stage.group(1))
                if stage is None:
                    continue  # External images do not establish committed lockfiles.
                for name, path in stage[0].items():
                    if name == source or name.startswith(source.rstrip("/") + "/"):
                        suffix = name[len(source.rstrip("/")):].lstrip("/")
                        target = posixpath.join(destination, suffix or posixpath.basename(source)) if directory or suffix else destination
                        self.files[target] = path
                continue
            expanded = self.expand(source, {})
            if not expanded or any(".." in Path(s).parts or s.startswith("/") for s in expanded):
                self.fail(location, f"cannot trace local COPY source {source!r}")
                continue
            for src in expanded:
                for match in ([self.context] if src in (".", "./") else self.context.glob(src)):
                    if not match.resolve().is_relative_to(self.context):
                        continue
                    if match.is_dir():
                        for path in match.rglob("*"):
                            if path.is_file() and self.included(path):
                                self.files[posixpath.join(destination, path.relative_to(match).as_posix())] = path
                    elif match.is_file() and self.included(match):
                        self.files[posixpath.join(destination, match.name) if directory else destination] = match

    def require(self, name, cwd, location, family):
        target = absolute(name, cwd)
        source = self.files.get(target)
        if source is None:
            self.fail(location, f"{family}: {target} must be copied from the build context before installation (check COPY and .dockerignore)")
            return
        try:
            text = source.read_text()
            if family == "Conda":
                lines = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("#")]
                if not lines or lines[0] != "@EXPLICIT" or len(lines) < 2:
                    raise ValueError("expected nonempty @EXPLICIT lockfile")
                if any(not re.fullmatch(r"https?://\S+#(?:[a-fA-F0-9]{32}|[a-fA-F0-9]{64})", line) for line in lines[1:]):
                    raise ValueError("explicit package URLs must include hashes")
            elif name.endswith(".toml") or name in ("uv.lock", "Cargo.lock"):
                data = tomllib.loads(text)
                if name.endswith(".lock") and not isinstance(data.get("version"), int):
                    raise ValueError("missing lockfile version")
            elif name.endswith(".json"):
                data = json.loads(text)
                if not isinstance(data, dict):
                    raise ValueError("expected a JSON object")
                if name == "package-lock.json" and "lockfileVersion" not in data:
                    raise ValueError("missing lockfileVersion")
            elif name.endswith(".yaml"):
                if yaml is None:
                    return
                data = yaml.safe_load(text)
                if not isinstance(data, dict) or "lockfileVersion" not in data:
                    raise ValueError("missing lockfileVersion")
        except (ValueError, OSError, *YAML_ERRORS) as exc:
            self.fail(location, f"{family}: invalid {source}: {exc}")

    def run(self, body, location, cwd=None, depth=0):
        if depth > 8:
            self.fail(location, "copied script recursion exceeds 8 calls")
            return
        cwd = self.cwd if cwd is None else cwd
        variables = {}
        for name, value in re.findall(r"\b(\w+)=(/[\w./-]+)", body):
            variables.setdefault(name, []).append(value)
        exports = set()
        # Quoted shell strings stay intact; only top-level control separators split.
        lexer = shlex.shlex(body, posix=True, punctuation_chars=";&|\n")
        lexer.whitespace = " \t\r"
        lexer.whitespace_split = True
        lexer.commenters = "#"
        segments, segment = [], []
        for word in lexer:
            if word and all(c in ";&|\n" for c in word):
                if segment:
                    segments.append(segment)
                segment = []
            else:
                segment.append(word)
        if segment:
            segments.append(segment)
        for words in segments:
            if words[0] == "cd" and len(words) > 1:
                cwd = absolute(words[1], cwd)
                continue
            # Inspect directly executed local scripts, not scripts copied for runtime.
            rejected_env = False
            while words:
                if re.match(r"^[A-Za-z_]\w*=", words[0]) or words[0] in ("then", "do"):
                    words = words[1:]
                elif posixpath.basename(words[0]) == "env":
                    words = words[1:]
                    while words and words[0].startswith("-"):
                        flag, words = words[0], words[1:]
                        if flag in ("-i", "--ignore-environment", "--") or flag.startswith("--unset="):
                            continue
                        if flag in ("-u", "--unset") and words:
                            words = words[1:]
                            continue
                        self.fail(location, "cannot trace env options for lockfile policy")
                        rejected_env = True
                        break
                    if rejected_env:
                        break
                else:
                    break
            if rejected_env or not words:
                continue
            executable = words[0]
            if executable in (".", "source"):
                script_path = self.files.get(absolute(words[1], cwd)) if len(words) > 1 else None
                if script_path is None:
                    self.fail(location, f"cannot trace sourced script {words[1] if len(words) > 1 else ''!r}")
                else:
                    self.run(script_path.read_text(), f"{location} -> {script_path}", cwd, depth + 1)
                continue
            if posixpath.basename(executable) == "corepack" and len(words) > 1 and words[1] == "pnpm":
                words, executable = words[1:], "pnpm"
            if re.fullmatch(r"python(?:3(?:\.\d+)?)?", posixpath.basename(executable)) and words[1:3] == ["-m", "uv"]:
                words, executable = ["uv", *words[3:]], "uv"
            shell = posixpath.basename(executable) in ("bash", "sh")
            if shell and any(w.startswith("-") and "c" in w[1:] for w in words[1:]):
                flag = next(i for i, w in enumerate(words[1:], 1) if w.startswith("-") and "c" in w[1:])
                if flag + 1 < len(words):
                    self.run(words[flag + 1], location, cwd, depth + 1)
                continue
            script = next((w for w in words[1:] if not w.startswith("-")), "") if shell else executable
            script_path = self.files.get(absolute(script, cwd))
            shell_script = False
            if script_path:
                with script_path.open("rb") as handle:
                    shell_script = re.match(rb"#![^\n]*\b(?:bash|sh)\b", handle.read(256)) is not None
            if script_path and (script.endswith(".sh") or shell or shell_script):
                self.run(script_path.read_text(), f"{location} -> {script_path}", cwd, depth + 1)
            if posixpath.basename(executable) == "rm":
                for operand in words[1:]:
                    if not operand.startswith("-"):
                        target = absolute(operand, cwd)
                        self.files = {name: path for name, path in self.files.items() if name != target and not name.startswith(target + "/")}
            positions = [0]
            if posixpath.basename(executable) == "uv" and len(words) > 1 and words[1] == "pip":
                positions = [1]
            if re.fullmatch(r"python(?:3(?:\.\d+)?)?", posixpath.basename(executable)) and words[1:3] == ["-m", "pip"]:
                positions = [2]
            for i in positions:
                word = words[i]
                manager = posixpath.basename(word)
                args = words[i + 1:]
                if not args:
                    continue
                offset = 0
                while offset < len(args) and (args[offset].startswith("-") or manager == "cargo" and args[offset].startswith("+")):
                    offset += 2 if args[offset] in ("--directory", "--project", "--prefix", "--dir", "-C", "--config", "--config-file") else 1
                command = args[offset] if offset < len(args) else None
                family = None
                if (manager == "uv" and (command in ("add", "remove") or command == "lock" and "--check" not in args)) or (manager == "cargo" and command in ("update", "generate-lockfile")):
                    self.fail(location, f"{manager} {command}: generate/update lockfiles before committing, not during image builds")
                elif manager == "uv" and command in ("sync", "export"):
                    family = "uv"
                    if "--locked" not in args or "--frozen" in args:
                        self.fail(location, "uv installs/exports require --locked (not just --frozen)")
                    project = option(args, "--project", "--directory") or cwd
                    paths = self.expand(project, variables)
                    if not paths:
                        self.fail(location, f"uv: cannot resolve project {project!r}; use a literal build-time path")
                    for path in paths:
                        for name in ("pyproject.toml", "uv.lock"):
                            self.require(name, absolute(path, cwd), location, family)
                    if command == "export":
                        output = option(args, "-o", "--output-file")
                        if output and "--locked" in args:
                            exports.add(absolute(output, cwd))
                elif re.fullmatch(r"pip(?:3(?:\.\d+)?)?", manager) and command == "install":
                    requirement = option(args, "-r", "--requirement")
                    if not (requirement and absolute(requirement, cwd) in exports and "--require-hashes" in args and "--no-deps" in args):
                        self.fail(location, "pip install requires a preceding uv export --locked and --require-hashes --no-deps")
                elif manager in ("npm", "pnpm") and command in ("ci", "install", "i", "add"):
                    family = manager
                    strict = command == "ci" if manager == "npm" else "--frozen-lockfile" in args and not any(a in ("--no-frozen-lockfile", "--frozen-lockfile=false") for a in args)
                    if not strict:
                        self.fail(location, f"{manager}: use {'npm ci' if manager == 'npm' else 'pnpm install --frozen-lockfile'}")
                    project = option(args, "--prefix", "--dir", "-C") or cwd
                    for name in ("package.json", "package-lock.json" if manager == "npm" else "pnpm-lock.yaml"):
                        self.require(name, absolute(project, cwd), location, family)
                elif manager == "cargo" and command in ("build", "fetch", "check", "test", "install"):
                    if not ({"--locked", "--frozen"} & set(args)):
                        self.fail(location, "Cargo: dependency installation requires --locked or --frozen")
                    manifest = option(args, "--manifest-path")
                    project = posixpath.dirname(absolute(manifest, cwd)) if manifest else cwd
                    for name in ("Cargo.toml", "Cargo.lock"):
                        self.require(name, project, location, "Cargo")
                elif manager in ("conda", "mamba", "micromamba") and (command in ("create", "install") or command == "env" and args[offset + 1:offset + 2] in (["create"], ["update"])):
                    install_args = args[offset + 2:] if command == "env" else args
                    lock = option(install_args, "--file", "-f")
                    paths = self.expand(lock, variables) if lock else []
                    if not paths:
                        self.fail(location, "Conda: use --file with a copied explicit lockfile; unresolved lock path")
                    for path in paths:
                        self.require(path, cwd, location, "Conda")

    def check(self):
        stage_name = None
        stage_number = -1
        for line, instruction in instructions(self.dockerfile.read_text()):
            parts = instruction.split(None, 1)
            keyword, body = parts[0], parts[1] if len(parts) > 1 else ""
            location = f"{self.dockerfile}:{line}"
            try:
                if keyword.upper() == "FROM":
                    if stage_number >= 0:
                        stage = (self.files.copy(), self.cwd, self.env.copy())
                        self.stages[str(stage_number)] = stage
                        if stage_name:
                            self.stages[stage_name] = stage
                    stage_number += 1
                    words = shlex.split(body)
                    base = next(w for w in words if not w.startswith("--"))
                    files, self.cwd, env = self.stages.get(base, ({}, "/", {}))
                    self.files, self.env = files.copy(), env.copy()
                    stage_name = words[-1] if len(words) >= 3 and words[-2].upper() == "AS" else None
                elif keyword.upper() == "WORKDIR":
                    paths = self.expand(body.strip('"'), {})
                    if len(paths) != 1:
                        self.fail(location, "cannot resolve WORKDIR; use a literal or declared ENV path")
                    else:
                        self.cwd = absolute(paths[0], self.cwd)
                elif keyword.upper() in ("ENV", "ARG"):
                    for word in shlex.split(body):
                        if "=" in word:
                            name, value = word.split("=", 1)
                            self.env[name] = [value]
                elif keyword.upper() in ("COPY", "ADD"):
                    if re.search(r"<<-?['\"]?[A-Za-z_]", body):
                        self.fail(location, "cannot trace COPY/ADD heredoc for lockfile policy")
                    else:
                        self.copy(body, location)
                elif keyword.upper() == "RUN":
                    if body in ("__UNSUPPORTED_HEREDOC__", "__UNTERMINATED_HEREDOC__"):
                        self.fail(location, body.lower().strip("_").replace("_", " "))
                    else:
                        body = re.sub(r"^(?:--[\w-]+=(?:\"[^\"]*\"|\S+)\s+)+", "", body)
                        if "<<" in body and "\n" in body:
                            header, script = body.split("\n", 1)
                            shebang = next((line for line in script.splitlines() if line.strip()), "")
                            shell_header = re.fullmatch(r"(?:(?:/bin/)?(?:bash|sh)\s+)?<<-?['\"]?[A-Za-z_]\w*['\"]?(?:\s+(?:bash|sh))?", header)
                            if shell_header and (not shebang.startswith("#!") or re.search(r"\b(?:bash|sh)\b", shebang)):
                                if re.search(r"<<-?['\"]?[A-Za-z_]", script):
                                    self.fail(location, "cannot trace nested RUN heredoc")
                                else:
                                    self.run(script, location)
                            elif re.search(r"\b(?:import\s+subprocess|from\s+subprocess\s+import)\b|\b(?:subprocess\.(?:run|call|check_call|check_output|Popen)|os\.(?:system|popen))\s*\(", script):
                                self.fail(location, "cannot trace dependency install in non-shell RUN heredoc")
                        else:
                            self.run(shlex.join(json.loads(body)) if body.startswith("[") else body, location)
            except (ValueError, OSError, IndexError) as exc:
                self.fail(location, f"cannot statically inspect instruction: {exc}")
        return self.errors


def task_findings(task):
    """FAIL lines for one task, as upstream's main() collects them."""
    errors = []
    contexts = {}
    for root in (task / "environment", task / "tests"):
        if not root.exists():
            continue
        for compose in (root.rglob("*compose*.y*ml") if yaml else ()):
            try:
                if not compose.resolve().is_relative_to(task.resolve()):
                    raise ValueError("Compose file symlink escapes task")
                data = yaml.safe_load(compose.read_text()) or {}
                if not isinstance(data, dict) or not isinstance(data.get("services", {}), dict):
                    raise ValueError("Compose services must be a mapping")
                for service in data.get("services", {}).values():
                    if not isinstance(service, dict):
                        raise ValueError("Compose service must be a mapping")
                    build = service.get("build")
                    if not build:
                        continue
                    build = {"context": build} if isinstance(build, str) else build
                    if not isinstance(build, dict):
                        raise ValueError("Compose build must be a path or mapping")
                    context = (compose.parent / build.get("context", ".")).resolve()
                    dockerfile = (context / build.get("dockerfile", "Dockerfile")).resolve()
                    if not context.is_relative_to(task.resolve()) or not dockerfile.is_relative_to(task.resolve()):
                        raise ValueError("build context/Dockerfile must stay inside task")
                    contexts[dockerfile] = context
            except (ValueError, OSError, *YAML_ERRORS) as exc:
                errors.append(f"FAIL {compose}: {exc}")
        for dockerfile in sorted(root.rglob("Dockerfile*")):
            if dockerfile.is_file() and (dockerfile.name == "Dockerfile" or dockerfile.name.startswith("Dockerfile.")) and not dockerfile.name.endswith(".dockerignore"):
                if not dockerfile.resolve().is_relative_to(task.resolve()):
                    errors.append(f"FAIL {dockerfile}: Dockerfile symlink escapes task")
                    continue
                errors.extend(Checker(dockerfile, contexts.get(dockerfile.resolve(), dockerfile.parent)).check())
    return errors


def findings(task):
    """[(path, line or None, message)] for every lockfile-policy failure in TASK's Dockerfiles."""
    task = Path(task)
    out = []
    for e in task_findings(task):
        loc, _, msg = e.removeprefix("FAIL ").partition(": ")
        loc = loc.split(" -> ")[0]
        path, _, line = loc.rpartition(":")
        out.append((path, int(line), msg) if path and line.isdigit() else (loc, None, msg))
    return out


def main():
    tasks = [Path(arg) for arg in sys.argv[1:]]
    errors = [e for task in tasks for e in task_findings(task)]
    print("\n".join(errors) if errors else "PASS lockfile policy")
    return bool(errors)


if __name__ == "__main__":
    sys.exit(main())
