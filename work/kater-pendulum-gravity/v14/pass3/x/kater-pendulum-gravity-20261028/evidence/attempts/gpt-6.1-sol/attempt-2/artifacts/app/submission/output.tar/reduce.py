#!/usr/bin/env python3
"""Reduce a reversible-pendulum release session in GPS seconds.

Angles are fitted through a common orthographic projection, using the
nonlinear rolling-pivot equation of motion and velocity-dependent damping.
GPS LED counters constrain clock rate and integer numbers of lost frames.
"""
import os
# Avoid oversubscribing the two-CPU runner.
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
 os.environ[key]='1'
import warnings
warnings.filterwarnings('ignore',category=RuntimeWarning)
from scipy.special import ellipk

from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix
import time

def clock_milp(z,gps):
 n=len(z);m=n-1
 # f, intercept, error, missing-frame counts, number of stalls
 A=lil_matrix((2*n+2*m+1,3+2*m))
 lo=np.full(A.shape[0],-np.inf);hi=np.zeros(A.shape[0])
 for i in range(n):
  A[2*i,0]=gps[i];A[2*i,1]=1;A[2*i,2]=-1;A[2*i,3:3+i]=-1;hi[2*i]=z[i]-.5
  A[2*i+1,0]=-gps[i];A[2*i+1,1]=-1;A[2*i+1,2]=-1;A[2*i+1,3:3+i]=1;hi[2*i+1]=-z[i]+.5
 for j in range(m):
  A[2*n+2*j,3+j]=1;A[2*n+2*j,3+m+j]=-15
  A[2*n+2*j+1,3+j]=-1;A[2*n+2*j+1,3+m+j]=2
 A[-1,3+m:]=1;hi[-1]=3
 obj=np.r_[0,0,1,np.zeros(m),np.ones(m)*1e-5]
 lb=np.r_[238.56,-np.inf,0,np.zeros(2*m)];ub=np.r_[241.44,np.inf,np.inf,np.ones(m)*45,np.ones(m)*3]
 integ=np.r_[0,0,0,np.ones(2*m)]
 res=milp(obj,integrality=integ,bounds=Bounds(lb,ub),constraints=LinearConstraint(A.tocsr(),lo,hi),options={'time_limit':8,'mip_rel_gap':1e-6})
 return res
import numpy as np, json, pathlib, itertools
from scipy.optimize import least_squares, linprog

def load(root,name):
 p=root/'runs'/f'{name}.csv'
 unit='rad'
 for line in p.open():
  if line.startswith('# unit:'): unit=line.strip().split(':')[1].strip()
  if not line.startswith('#'): break
 with p.open() as stream:
  lines=[line for line in stream if not line.startswith('#')]
 a=np.loadtxt(lines,delimiter=',',skiprows=1)
 c=np.unwrap(a[:,0]*2*np.pi/65536)*65536/(2*np.pi)
 c=np.round(c-c[0]).astype(int)
 y=a[:,1]*(np.pi/180 if unit=='deg' else 1)
 s=np.genfromtxt(root/'sync'/f'{name}.csv',delimiter=',',skip_header=1)
 n=np.array([np.where(a[:,0]==v)[0][0] for v in s[:,1]])
 z=c[n].astype(float); gps=s[:,0]-s[0,0]
 f=np.median(np.diff(z)/np.diff(gps))
 jumps=np.rint(f*np.diff(gps)-np.diff(z)).astype(int)
 jumps=np.where(jumps>=2,jumps,0)
 # initial approximate steps, then refine regression and steps
 for _ in range(8):
  dropped=np.r_[0,np.cumsum(jumps)]
  f,offset=np.linalg.lstsq(np.c_[gps,np.ones(len(gps))],z+dropped,rcond=None)[0]
  deficit=f*np.diff(gps)-np.diff(z)
  jumps=np.where(deficit>1.05,np.rint(deficit).astype(int),0)
 # maximize bounded clock fit feasibility: z+dropped = ceil(f*gps+offset)
 # fit midpoint then select center of feasible polygon using linprog
 exact=clock_milp(z,gps)
 if exact.x is not None:
  jumps=np.rint(exact.x[3:3+len(z)-1]).astype(int)
 dropped=np.r_[0,np.cumsum(jumps)]
 corrected=z+dropped
 # minimize residual range (should <=1)
 X=np.c_[gps,np.ones(len(gps))]
 sol=linprog([0,0,1],A_ub=np.r_[np.c_[X,-np.ones(len(gps))],np.c_[-X,-np.ones(len(gps))]],b_ub=np.r_[corrected-.5,-corrected+.5],bounds=[(238,242),(None,None),(0,None)],method='highs')
 f,offset,err=sol.x
 jumpidx=np.where(jumps>0)[0]
 tt=c.astype(float)
 valid=a[:,2]==1
 for j in jumpidx:
  tt[n[j+1]:]+=jumps[j]
  valid[n[j]:n[j+1]]=False
 t=(tt-offset)/f
 return t,y,valid, (f,err,[(float(gps[j]),int(jumps[j]),int(n[j]),int(n[j+1])) for j in jumpidx])

from scipy.signal import savgol_filter
from scipy.optimize import least_squares
import sys,time
root=pathlib.Path(sys.argv[1]); meta=json.load(open(root/'session.json'))
hA=meta['centre_of_mass']['from_pivot_a_m']+sum(v['mass_kg']*(v['mark_m']-meta['centre_of_mass']['weight_marks_m'][k])/meta['bar_mass_kg'] for k,v in meta['weights'].items())
h={'a':hA,'b':meta['pivot_separation_m']-hA}
r={p:meta['pivots'][p].get('pin_diameter_m',0)/2 for p in 'ab'}
runs=[]
for name,piv in meta['runs'].items():
 t,y,ok,info=load(root,name); dt=1/info[0]
 # use interpolated tracker data to get derivatives at regularly spaced frames
 yy=np.interp(np.arange(len(y)),np.where(ok)[0],y[ok])
 ys=savgol_filter(yy,49,6); v=savgol_filter(yy,49,6,deriv=1,delta=dt); acc=savgol_filter(yy,49,6,deriv=2,delta=dt)
 valid=np.convolve((~ok).astype(int),np.ones(49,dtype=int),mode="same")==0; valid[:650]=False; valid[-30:]=False
 for _,_,a,b in info[2]:valid[max(0,a-35):b+35]=False
 ix=np.where(valid & (np.arange(len(y))%15==0))[0]
 runs.append(dict(name=name,piv=piv,t=t,y=y,ok=ok,info=info,phi=ys[ix],v=v[ix],acc=acc[ix]))

def residual(x):
 C,D,rho=x[:3];res=[]
 for i,run in enumerate(runs):
  w,l,q,c=x[3+4*i:7+4*i]; phi=run['phi']-rho
  # angle theta = atan2(sin(phi), C*cos(phi)-D*sin(phi))
  s=np.sin(phi); co=np.cos(phi); den=C*co-D*s
  H=s*s+den*den;Hp=2*s*co+2*den*(-C*s-D*co)
  theta=np.arctan2(s,den); jac=C/H
  vel=jac*run['v']; ac=jac*run['acc']-C*Hp/H**2*run['v']**2
  eps=r[run['piv']]*w/9.81
  pred=-(w*np.sin(theta)+eps*np.sin(theta)*vel**2)/(1+2*eps*(1-np.cos(theta)))-l*vel-q*abs(vel)*vel-c*np.sign(vel)
  res.append((ac-pred)/jac)
 return np.concatenate(res)
x=np.r_[1.,0.,0.,np.tile([9.8,.006,.002,.001],len(runs))]
lo=np.r_[.72,-.4,-.06,np.tile([1.,-.03,-.02,-.03],len(runs))];hi=np.r_[1.25,.4,.06,np.tile([100.,.1,.1,.1],len(runs))]

ixinit=least_squares(residual,x,bounds=(lo,hi),x_scale='jac',max_nfev=80).x
from scipy.integrate import odeint
import math

# transform

def project(theta,cam):
 C,D,rho=cam
 return np.arctan2(C*np.sin(theta),np.cos(theta)+D*np.sin(theta))+rho

def inverse(phi,cam):
 C,D,rho=cam
 return np.arctan2(np.sin(phi-rho),C*np.cos(phi-rho)-D*np.sin(phi-rho))

for run in runs:
 t=run['t'];y=run['y'];ok=run['ok'];
 yy=np.interp(np.arange(len(y)),np.where(ok)[0],y[ok]); ys=savgol_filter(yy,49,4)
 releaseval=np.median(y[(t<t[0]+.4)&ok]);
 departure=np.where(abs(ys-releaseval)>.004)[0][0]
 run['release']=t[departure]-.06
 sel=ok & (np.arange(len(y))%8==0)
 run['ts']=t[sel];run['obs']=y[sel];run['plateau']=releaseval
 run['cached']=None

def integrate(p,run):
 w,l,q,c,amp,tr=p
 ts=run['ts']; eps=r[run['piv']]*w/9.81
 def fun(state,t):
  th,v=state; sn=math.sin(th); inertia=1+2*eps*(1-math.cos(th))
  return [v,(-w*sn-eps*sn*v*v-l*v-q*abs(v)*v-c*np.sign(v))/inertia]
 pos=np.maximum(ts-tr,0)
 return odeint(fun,[amp,0],np.r_[0,pos],rtol=1e-10,atol=1e-11,mxstep=1000)[1:,0]

def calc(x):
 outputs=[]
 for i,run in enumerate(runs):
  p=x[3+6*i:9+6*i]
  if run['cached'] is None or not np.array_equal(p,run['cached'][0]):
   run['cached']=(p.copy(),integrate(p,run))
  outputs.append(project(run['cached'][1],x[:3])-run['obs'])
 return np.concatenate(outputs)

x=list(ixinit[:3]);lo=[.65,-.5,-.07];hi=[1.35,.5,.07]
for i,run in enumerate(runs):
 w=ixinit[3+4*i];amp=inverse(run['plateau'],ixinit[:3]);tr=run['release']
 # Complete oscillations provide a phase-accurate starting frequency.
 tt=run['t']; yy=inverse(run['y'],ixinit[:3]); good=run['ok']
 sm=savgol_filter(np.interp(np.arange(len(yy)),np.where(good)[0],yy[good]),31,3)
 crossings=np.where((sm[:-1]<0)&(sm[1:]>=0))[0]
 estimates=[]; envelopes=[]
 for j in range(len(crossings)-1):
  a,b=crossings[j:j+2]
  if not np.all(good[a:b]):
   # Tracker gaps are harmless unless near a crossing, but stalls are not.
   if any(a<stop and b>start for _,_,start,stop in run['info'][2]):continue
  if b-a<.8*run['info'][0]:continue
  ta=tt[a]-sm[a]*(tt[a+1]-tt[a])/(sm[a+1]-sm[a])
  tb=tt[b]-sm[b]*(tt[b+1]-tt[b])/(sm[b+1]-sm[b])
  amplitude=(np.max(sm[a:b])-np.min(sm[a:b]))/2
  correction=2/np.pi*ellipk(np.sin(amplitude/2)**2)
  estimates.append((tb-ta)/correction);envelopes.append([(ta+tb)/2,amplitude])
 if estimates: w=(2*np.pi/np.median(estimates))**2
 damping=.02
 if len(envelopes)>4:
  env=np.array(envelopes);damping=float(np.clip(-2*np.polyfit(env[:,0],np.log(env[:,1]),1)[0],.001,.09))
 x.extend([w,damping,.005,0.,amp,tr]);lo.extend([1.,-.01,-.01,-.01,min(amp*.7,amp*1.3),run['t'][0]+.3]);hi.extend([100.,.1,.1,.1,max(amp*.7,amp*1.3),run['t'][0]+1.8])
x=np.array(x);lo=np.array(lo);hi=np.array(hi)
# Fit linear and quadratic drag; no dry-friction term is needed for these data.
active=np.array([j for j in range(len(x)) if j<3 or (j-3)%6!=3]);base=x.copy()
def unpack(z):
 v=base.copy();v[active]=z;return v
def jac(z):
 full=unpack(z); calc(full)
 J=np.zeros((sum(len(v['ts']) for v in runs),len(active)))
 start=0
 for i,run in enumerate(runs):
  n=len(run['ts']);p=full[3+6*i:9+6*i];theta=run['cached'][1];pred=project(theta,full[:3])
  for j in range(3):
   cam=full[:3].copy();cam[j]+=1e-6
   J[start:start+n,j]=(project(theta,cam)-pred)/1e-6
  for j in range(6):
   cols=np.where(active==3+6*i+j)[0]
   if not len(cols):continue
   delta=1e-5 if j!=3 else 1e-6
   pp=p.copy();pp[j]+=delta
   J[start:start+n,cols[0]]=(project(integrate(pp,run),full[:3])-pred)/delta
  start+=n
 return J
def obj(z):
 return calc(unpack(z))
fit=least_squares(obj,x[active],bounds=(lo[active],hi[active]),jac=jac,x_scale='jac',ftol=1e-9,xtol=1e-9,gtol=1e-8,max_nfev=70,verbose=0)
xx=unpack(fit.x)
frequencies={p:float(np.mean([xx[3+6*i] for i,run in enumerate(runs) if run['piv']==p])) for p in 'ab'}
g=(h['a']**2-h['b']**2)/((h['a']+r['a'])/frequencies['a']-(h['b']+r['b'])/frequencies['b'])
k2=g*(h['a']+r['a'])/frequencies['a']-h['a']**2
answer={'g_m_s2':float(g),'small_amplitude_period_s':{p:float(2*np.pi/np.sqrt(frequencies[p])) for p in 'ab'},'radius_of_gyration_m':float(np.sqrt(k2)), 'run_periods_s':{run['name']:float(2*np.pi/np.sqrt(xx[3+6*i])) for i,run in enumerate(runs)}, 'release_amplitude_rad':{run['name']:float(abs(xx[3+6*i+4])) for i,run in enumerate(runs)}}
print(json.dumps(answer,allow_nan=False))
