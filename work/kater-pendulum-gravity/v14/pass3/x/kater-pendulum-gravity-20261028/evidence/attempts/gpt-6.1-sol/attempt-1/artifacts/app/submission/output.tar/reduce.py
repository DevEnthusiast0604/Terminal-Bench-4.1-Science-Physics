#!/usr/bin/env python3
"""Reduce a filmed reversible pendulum session in GPS seconds.

The camera is an unknown orthographic projection. Its angle map is a
three-parameter projectivity of tan(theta); the same map is fitted to all
runs. Dynamics, including amplitude-dependent inertia of a rolling pin,
are fitted before computing the two-pivot gravimetric result.
"""
import os
# Avoid creating excessive BLAS threads in the restricted execution environment.
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import sys
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


def unwrap(c):
    c = np.asarray(c, dtype=np.int64)
    return np.r_[c[0], c[0] + np.cumsum((np.diff(c) + 32768) % 65536 - 32768)]


def read_run(path, name):
    with (path / 'runs' / (name + '.csv')).open() as f:
        lines = f.readlines()
    unit = next(s.split(':', 1)[1].strip() for s in lines if s.startswith('# unit'))
    rows = np.loadtxt([s for s in lines if not s.startswith('#')], delimiter=',', skiprows=1)
    c = unwrap(rows[:, 0])
    y = rows[:, 1] * (np.pi / 180 if unit == 'deg' else 1)
    ok = rows[:, 2] == 1
    sync = np.loadtxt(path / 'sync' / (name + '.csv'), delimiter=',', skiprows=1)
    gps = sync[:, 0] - sync[0, 0]
    sc = unwrap(sync[:, 1])
    sc += round((c[0] - sc[0]) / 65536) * 65536

    # Fit oscillator slope and changes of intercept at sensor stalls.
    # A first-lit frame quantizes the GPS check to a one-frame interval.
    slopes = np.diff(sc) / np.diff(gps)
    dt0 = gps[None, :] - gps[:, None]
    dc0 = sc[None, :] - sc[:, None]
    local = (dt0 >= 4) & (dt0 <= 8)
    rate = np.median(dc0[local] / dt0[local])
    bad = np.flatnonzero((rate - slopes) * np.diff(gps) > 1.25)
    for iteration in range(12):
        segsync = np.zeros(len(sc), dtype=int)
        for i in bad:
            segsync[i + 1:] += 1
        X = np.column_stack([gps] + [(segsync == j).astype(float) for j in range(len(bad) + 1)])
        coef = np.linalg.lstsq(X, sc, rcond=None)[0]
        rate = coef[0]
        # The quantized first-frame observations cannot wander by more
        # than one frame around a straight clock line. A two-frame stall
        # may be disguised as a one-frame adjacent-counter deficit.
        newbad = set(bad.tolist())
        for segid in range(len(bad) + 1):
            ix = np.flatnonzero(segsync == segid)
            if len(ix) < 5:
                continue
            gg = gps[ix]
            cc = sc[ix]
            dtt = gg[None,:] - gg[:,None]
            dcc = cc[None,:] - cc[:,None]
            mm = dtt > 0
            low = np.max((dcc[mm]-1)/dtt[mm])
            high = np.min((dcc[mm]+1)/dtt[mm])
            if low <= high + 1e-7:
                continue
            # Locate a downward change in the detrended counter using
            # two-mean change-point costs. Rounding excursions are <1.
            z = cc - rate*gg
            bestcost = np.inf
            bestsplit = None
            for split in range(2, len(ix)-1):
                before, after = z[:split], z[split:]
                if np.mean(before)-np.mean(after) < .9:
                    continue
                cost = np.sum((before-np.mean(before))**2) + np.sum((after-np.mean(after))**2)
                if cost < bestcost:
                    bestcost = cost
                    bestsplit = ix[split-1]
            if bestsplit is not None:
                newbad.add(int(bestsplit))
        newbad = np.asarray(sorted(newbad), dtype=int)
        if np.array_equal(newbad, bad):
            break
        bad = newbad

    # Exact interval bounds on slope, using only pairs in the same segment.
    dt = gps[None, :] - gps[:, None]
    dc = sc[None, :] - sc[:, None]
    mask = (dt > 0) & (segsync[None, :] == segsync[:, None])
    lo = np.max((dc[mask] - 1) / dt[mask])
    hi = np.min((dc[mask] + 1) / dt[mask])
    rate = (lo + hi) / 2 if lo <= hi + 1e-7 else coef[0]

    t = (c - c[0]).astype(float) / rate
    seg = np.zeros(len(c), dtype=int)
    for j, i in enumerate(bad):
        # The restart time is unknown within this GPS interval. Do not
        # pretend its counter supplies elapsed time for these frames.
        ok[(c >= sc[i]) & (c <= sc[i + 1])] = False
        later = c >= sc[i + 1]
        t[later] += round(coef[j + 1] - coef[j + 2]) / rate
        seg[later] += 1

    hold = np.mean(y[ok & (t < .4)])
    yi = np.interp(t, t[ok], y[ok])
    smooth = gaussian_filter1d(yi, 5)
    # Frequency estimate from the latter part of a run is close to the
    # infinitesimal-amplitude frequency, independently of the camera.
    tail = t > max(8., t[-1] * .45)
    vals = smooth[tail] - np.mean(smooth[tail])
    freqs = np.fft.rfftfreq(len(vals), 1 / rate)
    power = np.abs(np.fft.rfft(vals))
    band = (freqs > .12) & (freqs < 3)
    fi = np.flatnonzero(band)[np.argmax(power[band])]
    Tapprox = 1 / freqs[fi]
    peaks, _ = find_peaks(smooth, distance=max(10, int(.65 * Tapprox * rate)), prominence=max(.003, .03 * np.ptp(smooth[tail])))
    peaks = peaks[t[peaks] > max(5., t[-1] * .4)]
    # Local parabolic interpolation removes frame-quantization of maxima.
    pt = []
    for i in peaks:
        a = max(0, i - 6); b = min(len(t), i + 7)
        xx = t[a:b] - t[i]
        poly = np.polyfit(xx, smooth[a:b], 2)
        pt.append(t[i] - poly[1] / (2 * poly[0]))
    T = np.median(np.diff(pt)) if len(pt) >= 4 else Tapprox
    amp_tail = .5 * (np.percentile(smooth[tail], 98) - np.percentile(smooth[tail], 2))
    T /= 1 + amp_tail * amp_tail / 16
    w = 2 * np.pi / T
    moved = np.flatnonzero(ok & (t > .4) & (np.abs(y - hold) > .006))
    release = t[moved[0]] - np.sqrt(.012 / max(.05, abs(hold) * w * w))
    release = np.clip(release, .5, 1.5)
    return dict(t=t, y=y, ok=ok, seg=seg, nseg=len(bad), hold=hold, w=w, release=release, rate=rate, gps=gps, sc=sc, bad=bad, coef=coef, segsync=segsync)


def trajectory(t, params, camera, beta):
    """Image angle and analytic derivatives, integrating variational ODEs."""
    w, d1, d2, amplitude, release = params
    active = t > release
    ts = t[active] - release

    def rhs(time, z):
        a, v = z[:2]
        s, c = np.sin(a), np.cos(a)
        D = 1 + 2 * beta * (1 - c)
        F = (-w*w*s - beta*s*v*v - d1*v - d2*abs(v)*v) / D
        Fa = (-w*w*c - beta*c*v*v - 2*beta*s*F) / D
        Fv = (-2*beta*s*v - d1 - 2*d2*abs(v)) / D
        out = np.empty(10)
        out[:2] = v, F
        out[2:6] = z[6:10]
        out[6:10] = Fa*z[2:6] + Fv*z[6:10]
        out[6:9] += np.array([-2*w*s, -v, -abs(v)*v]) / D
        return out

    initial = np.zeros(10)
    initial[0] = amplitude
    initial[5] = 1
    sol = solve_ivp(rhs, (0, ts[-1]), initial, t_eval=ts,
                    method='DOP853', rtol=5e-9, atol=5e-11)
    a = np.full(len(t), amplitude)
    v = np.zeros(len(t))
    deriv = np.zeros((len(t), 5))
    deriv[~active, 3] = 1
    a[active] = sol.y[0]
    v[active] = sol.y[1]
    deriv[active, :4] = sol.y[2:6].T
    deriv[active, 4] = -v[active]
    off, p, q = camera
    s, c = np.sin(a), np.cos(a)
    den, num = c + q*s, p*s
    R = den*den + num*num
    pred = off + np.arctan2(num, den)
    jc = np.column_stack([np.ones(len(t)), s*den/R, -p*s*s/R])
    jr = deriv * (p/R)[:, None]
    return pred, jc, jr, v*p/R


class Reduction:
    def __init__(self, path):
        self.meta = json.load((path / 'session.json').open())
        m = self.meta
        self.names = list(m['runs'])
        h = m['centre_of_mass']['from_pivot_a_m']
        for name, weight in m['weights'].items():
            h += weight['mass_kg'] * (weight['mark_m'] - m['centre_of_mass']['weight_marks_m'][name]) / m['bar_mass_kg']
        self.h = {'a': h, 'b': m['pivot_separation_m'] - h}
        self.r = {p: m['pivots'][p].get('pin_diameter_m', 0.) / 2 for p in self.h}
        self.runs = [read_run(path, n) for n in self.names]
        x = [0., 1., 0.]
        lb = [-.1, .65, -.5]
        ub = [.1, 1.5, .5]
        for run in self.runs:
            w = run['w']
            x.extend([w, .022, .02, np.clip(run['hold'], -1.1, 1.1), run['release']])
            lb.extend([w*.8, 0., 0., -1.4, .4])
            ub.extend([w*1.2, .2, .2, 1.4, 1.6])
        for run in self.runs:
            run['offset_indices'] = np.arange(len(x), len(x) + run['nseg'], dtype=int)
            x.extend([0.] * run['nseg'])
            lb.extend([-.025] * run['nseg'])
            ub.extend([.025] * run['nseg'])
        self.x = np.asarray(x)
        self.bounds = (np.asarray(lb), np.asarray(ub))
        self.beta = []
        self.update_inertia()

    def gravity(self):
        # At equilibrium: omega_p^2 = g*(h_p+r_p)/(k^2+h_p^2).
        w = {p: np.mean([self.x[3+5*i] for i, n in enumerate(self.names) if self.meta['runs'][n] == p]) for p in self.h}
        u = {p: (self.h[p] + self.r[p]) / w[p]**2 for p in w}
        g = (self.h['b']**2 - self.h['a']**2) / (u['b'] - u['a'])
        k2 = g*u['a'] - self.h['a']**2
        return g, k2, w

    def update_inertia(self):
        _, k2, _ = self.gravity()
        if not np.isfinite(k2) or k2 <= 0:
            k2 = self.h['a'] * self.h['b']
        self.beta = []
        for n in self.names:
            p = self.meta['runs'][n]
            h, r = self.h[p], self.r[p]
            self.beta.append(r*(h+r)/(k2+h*h))

    def fit(self, end, stride, maxeval=30):
        data = []
        for run in self.runs:
            ix = np.flatnonzero(run['ok'] & (run['t'] < end))[::stride]
            data.append((run['t'][ix], run['y'][ix], run['seg'][ix], run['offset_indices']))
        # Segment offsets occurring after this fitting stage are not yet free.
        used = list(range(3 + 5*len(self.names)))
        for t, y, seg, inds in data:
            used.extend(inds[j-1] for j in np.unique(seg) if j > 0)
        used = np.asarray(used, dtype=int)
        base = self.x.copy()
        size = sum(len(d[0]) for d in data)
        cache = {}

        def evaluate(z):
            if 'z' in cache and np.array_equal(z, cache['z']):
                return
            x = base.copy()
            x[used] = z
            J = np.zeros((size, len(x)))
            residuals = []
            pos = 0
            for i, (t, y, seg, inds) in enumerate(data):
                shifts = np.r_[0., x[inds]]
                tt = t + shifts[seg]
                pred, jc, jr, vel = trajectory(tt, x[3+5*i:8+5*i], x[:3], self.beta[i])
                n = len(t)
                J[pos:pos+n, :3] = jc
                J[pos:pos+n, 3+5*i:8+5*i] = jr
                for j, idx in enumerate(inds):
                    J[pos:pos+n, idx] = vel * (seg == j+1)
                residuals.append(pred-y)
                pos += n
            cache.update(z=z.copy(), residuals=np.concatenate(residuals), jac=J[:, used])

        def fun(z):
            evaluate(z)
            return cache['residuals']

        def jac(z):
            evaluate(z)
            return cache['jac']

        result = least_squares(fun, base[used], jac=jac,
                               bounds=(self.bounds[0][used], self.bounds[1][used]),
                               x_scale='jac', ftol=2e-8, xtol=2e-9, gtol=2e-8,
                               max_nfev=maxeval)
        self.x[used] = result.x
        print('fit', end, 'evaluations', result.nfev, 'rms', np.sqrt(np.mean(result.fun**2)), file=sys.stderr)

    def refine_clocks(self):
        for i, run in enumerate(self.runs):
            rate = run['rate']
            inds = run['offset_indices']
            missing = np.rint(run['coef'][1:-1] - run['coef'][2:]).astype(int)
            cumulative = np.r_[0, np.cumsum(missing)]
            fitted = np.r_[0., self.x[inds]]
            counts = np.rint(cumulative + fitted*rate)
            corrected = run['sc'] + counts[run['segsync']]
            keep = np.ones(len(corrected), dtype=bool)
            for j in run['bad']:
                keep[max(0,j-1):min(len(keep),j+3)] = False
            gps = run['gps'][keep]
            sc = corrected[keep]
            dt = gps[None,:] - gps[:,None]
            dc = sc[None,:] - sc[:,None]
            mask = dt > 0
            lo = np.max((dc[mask]-1)/dt[mask])
            hi = np.min((dc[mask]+1)/dt[mask])
            if lo <= hi + 1e-7:
                newrate = (lo+hi)/2
            else:
                newrate = np.polyfit(gps, sc, 1)[0]
            ratio = rate/newrate
            run['t'] *= ratio
            self.x[3+5*i] /= ratio
            self.x[4+5*i] /= ratio
            self.x[7+5*i] *= ratio
            self.x[inds] *= ratio
            run['rate'] = newrate

    def reduce(self):
        self.fit(22., 5, 35)
        self.update_inertia()
        self.fit(np.inf, 4, 25)
        self.update_inertia()
        self.refine_clocks()
        # Correct the very small dependence of rolling inertia on the newly
        # inferred k. Final fitting also uses every other valid frame.
        self.fit(np.inf, 2, 15)
        g, k2, w = self.gravity()
        return {
            'g_m_s2': float(g),
            'small_amplitude_period_s': {p: float(2*np.pi/w[p]) for p in ['a', 'b']},
            'radius_of_gyration_m': float(np.sqrt(k2)),
            'run_periods_s': {n: float(2*np.pi/self.x[3+5*i]) for i, n in enumerate(self.names)},
            'release_amplitude_rad': {n: float(abs(self.x[6+5*i])) for i, n in enumerate(self.names)}
        }


if __name__ == '__main__':
    print(json.dumps(Reduction(Path(sys.argv[1])).reduce(), allow_nan=False, separators=(',', ':')))
