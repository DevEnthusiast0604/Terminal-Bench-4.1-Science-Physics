#!/usr/bin/env python3
"""Reduce an orthographically tracked reversible-pendulum release session.

GPS LED records calibrate elapsed time.  The shared camera is fitted as an
orthographic angle homography; each run has its own undamped frequency,
release time/amplitude, and linear and quadratic dissipation coefficients.
Rolling pivots are treated as rolling rigid bodies, not stationary hinges.
"""
import os
# Limit BLAS to one worker; integration and fitting use the other CPU budget
# without oversubscribing the very small linear algebra operations.
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_v] = "1"
import warnings
warnings.filterwarnings("ignore")

import numpy as np, json
from pathlib import Path
from scipy.signal import find_peaks, savgol_filter

def load(p,r):
 path=p/'runs'/f'{r}.csv'
 with open(path) as f:
  lines=f.readlines()
 unit=[x.split(':')[1].strip() for x in lines if x.startswith('# unit')][0]
 n=next(i for i,x in enumerate(lines) if not x.startswith('#'))
 d=np.loadtxt(lines[n+1:],delimiter=',')
 c=np.unwrap(d[:,0]*2*np.pi/65536)*65536/(2*np.pi)
 y=d[:,1]*(np.pi/180 if unit=='deg' else 1)
 s=np.loadtxt(p/'sync'/f'{r}.csv',delimiter=',',skiprows=1)
 sc=np.unwrap(s[:,1]*2*np.pi/65536)*65536/(2*np.pi)
 sc+=round((c[0]-sc[0])/65536)*65536
 return c,y,d[:,2]>0,s[:,0]-s[0,0],sc


import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix

def integer_clock(st,sc):
 n=len(st); k=n-1
 # f, phase, cumulative loss per LED, binary stall indicators
 nv=2+n+k
 A=lil_matrix((n+2*k+1,nv));low=[];high=[]
 for i in range(n):
  A[i,0]=-st[i];A[i,1]=-1;A[i,2+i]=1
  low.append(-sc[i]);high.append(1-sc[i])
 for i in range(k):
  j=n+2*i
  A[j,2+i+1]=1;A[j,2+i]=-1;A[j,2+n+i]=-2
  low.append(0);high.append(np.inf)
  A[j+1,2+i+1]=1;A[j+1,2+i]=-1;A[j+1,2+n+i]=-15
  low.append(-np.inf);high.append(0)
 A[-1,2+n:]=1;low.append(0);high.append(3)
 lo=np.r_[238.56,sc[0]-1,np.zeros(n),np.zeros(k)]
 hi=np.r_[241.44,sc[0],np.full(n,45),np.full(k,3)];hi[2]=0
 integ=np.r_[0,0,np.ones(n+k)]
 obj=np.r_[0,0,np.zeros(n),np.ones(k)]
 fit=milp(obj,integrality=integ,bounds=Bounds(lo,hi),constraints=LinearConstraint(A.tocsr(),low,high),options={'time_limit':20,'mip_rel_gap':0})
 if fit.x is None:raise RuntimeError('clock fit failed')
 corr=np.round(fit.x[2:2+n]); jumps=np.where(np.diff(corr)>0)[0];loss=np.diff(corr)[jumps].astype(int)
 dx=(sc+corr)[None,:]-(sc+corr)[:,None];dt=st[None,:]-st[:,None];ix=dt>0
 fl=np.max((dx[ix]-1-1e-7)/dt[ix]);fh=np.min((dx[ix]+1+1e-7)/dt[ix]);f=(fl+fh)/2
 return f,jumps,loss,fl,fh

import numpy as np
from scipy.integrate import quad
from scipy.optimize import minimize_scalar
from itertools import product

def area(st,z):
 dx=z[None,:]-z[:,None];dt=st[None,:]-st[:,None];mask=dt>0
 lo=max(238.56,np.max((dx[mask]-1)/dt[mask])); hi=min(241.44,np.min((dx[mask]+1)/dt[mask]))
 if hi<=lo+1e-10:return 0,(lo+hi)/2
 def width(f):return max(0,1-np.ptp(z-f*st))
 # piecewise linear width, quadrature adequate at this scale
 aa=quad(width,lo,hi,epsabs=1e-12,limit=100)[0]
 ff=quad(lambda f:(f-lo)*width(f),lo,hi,epsabs=1e-13,limit=100)[0]/aa+lo
 return aa,ff

def clock_candidates(st,sc):
 f,breaks,loss,fl,fh=integer_clock(st,sc)
 # unambiguous discontinuities plus moderate candidate jumps
 ds=np.diff(st);dc=np.diff(sc)
 candidate=np.where(dc-f*ds < -1.000001)[0]
 candidate=np.unique(np.r_[candidate,breaks])
 # reject clock-quantization-only steps by minimum stall >=2
 # keep to at most 3 potential intervals
 best=(0,f,breaks,loss)
 solutions=[]
 options=[]
 for j in candidate:
  rough=int(round(f*ds[j]-dc[j])); options.append(sorted(set([0]+[v for v in range(rough-1,rough+2) if 2<=v<=45])))
 if len(candidate)>8:return [(1,f,breaks,loss)]
 for ls in product(*options):
  ls=np.array(ls); bb=candidate[ls>0];ll=ls[ls>0]
  if sum((int(v)+14)//15 for v in ll)>3:continue
  corr=np.zeros(len(sc));corr[bb+1]=ll;corr=np.cumsum(corr)
  aa,ff=area(st,sc+corr)
  if aa>0:solutions.append((aa,ff,bb,ll))
  if aa>best[0]:best=(aa,ff,bb,ll)
 return sorted(solutions,key=lambda v:-v[0]) or [best]

import numpy as np, json, sys, time
from pathlib import Path
from scipy.signal import savgol_filter
from scipy.optimize import least_squares

def calibrate_clock(st,sc):
 return clock_candidates(st,sc)[0][1:]

def clock(c,st,sc):
 f,jumps,loss=calibrate_clock(st,sc)
 t=(c-c[0])/f
 keep=np.ones(len(c),bool)
 regions=[]
 for j,l in zip(jumps,loss):
  cl=sc[j]; ch=sc[j+1]
  keep &= ~((c>=cl-30)&(c<=ch+30))
  t[c>=(cl+ch)/2]+=l/f
  regions.append((cl,ch,l))
 return t,keep,f,regions

def inverse(y,a,b,roll):
 z=y-roll; s=np.sin(z); c=np.cos(z); u=a*c-b*s
 D=s*s+u*u; Dp=2*s*c+2*u*(-a*s-b*c)
 return np.arctan2(s,u),a/D,-a*Dp/D**2

def setup(p):
 meta=json.load(open(p/'session.json'))
 h=meta['centre_of_mass']['from_pivot_a_m']
 for w,v in meta['weights'].items(): h+=v['mass_kg']*(v['mark_m']-meta['centre_of_mass']['weight_marks_m'][w])/meta['bar_mass_kg']
 hs={'a':h,'b':meta['pivot_separation_m']-h}
 radii={pv:meta['pivots'][pv].get('pin_diameter_m',0)/2 for pv in ['a','b']}
 out=[]
 for run,pv in meta['runs'].items():
  c,y,ok,st,sc=load(p,run); t,keep,f,regions=clock(c,st,sc)
  yy=np.interp(c,c[ok],y[ok]); n=101
  sm=savgol_filter(yy,n,7); v=savgol_filter(yy,n,7,deriv=1,delta=1/f); ac=savgol_filter(yy,n,7,deriv=2,delta=1/f)
  mask=keep & (t>2) & (t<t[-1]-.4) & (np.convolve((~ok).astype(int),np.ones(n,dtype=int),mode='same')==0)
  # do not use neighborhoods of gaps/stalls
  for cl,ch,l in regions: mask &= ~((c>=cl-60)&(c<=ch+60))
  ix=np.where(mask)[0][::8]
  out.append(dict(run=run,pv=pv,h=hs[pv],r=radii[pv],c=c,y=y,ok=ok,t=t,f=f,regions=regions,sm=sm[ix],v=v[ix],ac=ac[ix]))
 return meta,out

def firstfit(meta,runs):
 nr=len(runs)
 # roll, a, b, then (w2,linear,quadratic,constant) per run
 x=[0,1,0]
 for d in runs:
  y=d['sm']; nzero=np.sum(np.diff(np.sign(y-np.mean(y)))!=0)
  T=2*(d['t'][-1]-2)/nzero
  x.extend([(2*np.pi/T)**2,.025,.02,0])
 def resid(x):
  roll,a,b=x[:3]; out=[]
  for i,d in enumerate(runs):
   w2,l,q,k=x[3+4*i:7+4*i]
   th,j,jp=inverse(d['sm'],a,b,roll); v=j*d['v']; ac=j*d['ac']+jp*d['v']**2
   eps=2*d['r']*w2/9.81
   rr=ac+(w2*np.sin(th)+.5*eps*np.sin(th)*v*v)/(1+eps*(1-np.cos(th)))+l*v+q*v*np.abs(v)+k*np.tanh(v/.04)
   out.append(rr)
  return np.concatenate(out)
 lo=[-.08,.75,-.5]+[5,-.1,-.1,-.1]*nr; hi=[.08,1.2,.5]+[16,.2,.2,.1]*nr
 fit=least_squares(resid,x,bounds=(lo,hi),x_scale='jac',ftol=1e-10,xtol=1e-10,gtol=1e-10)
 print('initial',fit.x[:3], 'rms',np.std(fit.fun),file=sys.stderr)
 for i,d in enumerate(runs):print(d['run'],d['f'],fit.x[3+4*i:7+4*i], 'period',2*np.pi/np.sqrt(fit.x[3+4*i]),file=sys.stderr)
 return fit.x

import numpy as np, sys, time
from pathlib import Path
from scipy.integrate import odeint
from scipy.optimize import least_squares

def project(th,a,b,roll):
 return roll+np.arctan2(a*np.sin(th),np.cos(th)+b*np.sin(th))

def trajectory(times,x,camera,held,r,mode=0):
 roll,a,b=camera; w2,l,q,held,t0=x
 theta0=inverse(np.array([held]),a,b,roll)[0][0]
 eps=2*r*w2/9.81
 def rhs(y,t):
  th,v=y; mass=1+eps*(1-np.cos(th))
  damp=l*v+q*v*abs(v)
  return v,(-w2*np.sin(th)-eps/2*np.sin(th)*v*v-damp)/(mass if mode==0 else 1)- (eps*(1-np.cos(th))*(w2*np.sin(th)+eps/2*np.sin(th)*v*v)/mass if mode==1 else 0)
 # mode 1 equals damping outside inertia
 u=times-t0; moving=u>0
 tout=np.r_[0,u[moving]]
 states=odeint(rhs,[theta0,0],tout,rtol=2e-9,atol=2e-10,mxstep=5000)
 theta=np.full(times.shape,theta0); theta[moving]=states[1:,0]
 return project(theta,a,b,roll)

def fit(meta,runs,initial,mode=0):
 nr=len(runs)
 x=list(initial[:3])
 for i,d in enumerate(runs):
  t,y,ok=d['t'],d['y'],d['ok']; held=np.median(y[(t<.4)&ok]); d['held']=held
  first=np.where(ok & (abs(y-held)>.002)&(t>.4))[0][0]
  t0=t[first]-.04
  t0=np.clip(t0,.5,1.5)
  d['ix']=np.where(ok & ((np.arange(len(t))%8==0) | (t<1.6)))[0]
  for cl,ch,n in d['regions']:
   d['ix']=d['ix'][~((d['c'][d['ix']]>=cl-3)&(d['c'][d['ix']]<=ch+3))]
  if len(initial)==3+5*nr:
   w,l,q,held,t0=initial[3+5*i:8+5*i]
  else:
   w,l,q,k=initial[3+4*i:7+4*i]
  x.extend([w,max(.003,l),max(.003,q),held,t0])
 lo=[-.05,.78,-.35]+sum(([8,0,0,d['held']-.01,.45] for d in runs),[])
 hi=[.05,1.11,.35]+sum(([14,.1,.1,d['held']+.01,1.55] for d in runs),[])
 x=np.clip(x,np.array(lo)+1e-6,np.array(hi)-1e-6)
 sizes=[len(d['ix']) for d in runs]; offsets=np.r_[0,np.cumsum(sizes)]
 cache={'x':None,'pred':None}; neval=0
 def predone(x,i):
  d=runs[i]; ix=d['ix']
  return trajectory(d['t'][ix],x[3+5*i:8+5*i],x[:3],d['held'],d['r'],mode)
 def resid(x):
  nonlocal neval
  pred=[predone(x,i) for i in range(nr)]; cache['x']=x.copy();cache['pred']=pred
  neval+=1
  rr=np.concatenate([pred[i]-runs[i]['y'][runs[i]['ix']] for i in range(nr)])
  if neval%5==1:print('fit',neval,'rms',np.std(rr),'cam',x[:3],file=sys.stderr)
  return rr
 def jac(x):
  if cache['x'] is None or np.any(cache['x']!=x):resid(x)
  pred=cache['pred']; J=np.zeros((offsets[-1],len(x)))
  for j in range(len(x)):
   dx=1e-5 if j<3 else (1e-5 if (j-3)%5==4 else 1e-5)
   xx=x.copy();xx[j]+=dx
   for i in (range(nr) if j<3 else [(j-3)//5]):
    J[offsets[i]:offsets[i+1],j]=(predone(xx,i)-pred[i])/dx
  return J
 start=time.time()
 f=least_squares(resid,x,jac=jac,bounds=(lo,hi),x_scale='jac',ftol=2e-8,xtol=2e-8,gtol=2e-8,max_nfev=35)
 print('DONE',time.time()-start,f.x,'rms',np.std(f.fun),file=sys.stderr)
 for i,d in enumerate(runs):
  print(d['run'],f.x[3+5*i:8+5*i], 'T',2*np.pi/np.sqrt(f.x[3+5*i]), 'rms',np.std(f.fun[offsets[i]:offsets[i+1]]),file=sys.stderr)
 return f.x


def resolve_clocks(folder,runs,x):
    changed=False
    for i,d in enumerate(runs):
        c,y,ok,st,sc=load(folder,d['run'])
        choices=clock_candidates(st,sc)
        choices=[v for v in choices if v[0]>=choices[0][0]*1e-4][:16]
        if len(choices)<2: continue
        # Identical angle samples for every candidate. Intervals where the
        # GPS detector brackets a stall are omitted, not interpolated in time.
        ix=np.where(ok & ((np.arange(len(c))%12==0) | (d['t']<1.6)))[0]
        for _,f,bb,ll in choices:
            for j in bb:
                ix=ix[~((c[ix]>=sc[j]-3)&(c[ix]<=sc[j+1]+3))]
        best=None
        for aa,f,bb,ll in choices:
            tt=(c-c[0])/f
            for j,n in zip(bb,ll): tt[c>=(sc[j]+sc[j+1])/2]+=n/f
            xx=x[3+5*i:8+5*i].copy()
            xx[0]*=(f/d['f'])**2
            held=xx[3]
            def residual(par):
                return trajectory(tt[ix],par,x[:3],held,d['r'])-y[ix]
            opt=least_squares(residual,xx,bounds=([8,0,0,held-.01,.45],[14,.1,.1,held+.01,1.55]),x_scale='jac',diff_step=1e-5,max_nfev=15,ftol=1e-7,xtol=1e-7,gtol=1e-7)
            cost=float(np.mean(opt.fun**2))
            if best is None or cost<best[0]: best=(cost,f,bb,ll,tt,opt.x)
        cost,f,bb,ll,tt,xx=best
        if abs(f-d['f'])>1e-8:
            changed=True
            print('motion clock',d['run'],f,ll,'rms',cost**.5,file=sys.stderr)
            d['t']=tt;d['f']=f
            d['regions']=[(sc[j],sc[j+1],int(n)) for j,n in zip(bb,ll)]
            x[3+5*i:8+5*i]=xx
    return changed

def main():
    meta, runs = setup(Path(sys.argv[1]))
    initial = firstfit(meta, runs)
    x = fit(meta, runs, initial)
    if resolve_clocks(Path(sys.argv[1]),runs,x):
        x = fit(meta,runs,x)
    w = {p: float(np.mean([x[3+5*i] for i,d in enumerate(runs) if d['pv']==p])) for p in ('a','b')}
    h = {d['pv']: d['h'] for d in runs}
    r = {d['pv']: d['r'] for d in runs}
    # omega^2 = g(h+r)/(k^2+h^2).  h is measured from the
    # rest contact line, whereas h+r is the pin-centre-to-COM distance.
    g = (h['b']**2-h['a']**2)/((h['b']+r['b'])/w['b']-(h['a']+r['a'])/w['a'])
    k2 = g*(h['a']+r['a'])/w['a']-h['a']**2
    result = {
        'g_m_s2': float(g),
        'small_amplitude_period_s': {p: float(2*np.pi/np.sqrt(w[p])) for p in ('a','b')},
        'radius_of_gyration_m': float(np.sqrt(k2)),
        'run_periods_s': {d['run']: float(2*np.pi/np.sqrt(x[3+5*i])) for i,d in enumerate(runs)},
        'release_amplitude_rad': {d['run']: float(abs(inverse(np.array([x[6+5*i]]),x[1],x[2],x[0])[0][0])) for i,d in enumerate(runs)}
    }
    print(json.dumps(result, allow_nan=False, separators=(',',':')))

if __name__ == '__main__':
    main()
