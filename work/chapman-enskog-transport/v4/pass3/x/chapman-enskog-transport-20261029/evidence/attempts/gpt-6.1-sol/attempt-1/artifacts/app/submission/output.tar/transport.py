#!/usr/bin/env python3
"""Classical dilute-gas transport for the spherical-core Kihara potential.

Units: sigma = epsilon = molecular mass = Boltzmann constant = 1.
The linearized collision equations are solved in nested, orthonormal
Sonine Galerkin spaces, not by the first-Sonine collision-integral formulas.
Scattering is calculated from the potential, including both orbiting
branches. Angular harmonic projection analytically reduces the Maxwellian
centre-of-mass averages to finite Gaussian quadratures.
"""
import os
# Keep numerical-library thread pools within the supplied CPU allocation.
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import sys
import json
import numpy as np
from scipy.special import roots_genlaguerre, roots_legendre, eval_genlaguerre, lpmv, gammaln

def kernels(x, N=10):
    # Normalized vector/tensor Sonine bases, summed over their components.
    z,wz=roots_genlaguerre(N+2,.5); wz*=2/np.sqrt(np.pi)
    mu,wm=roots_legendre(N+3); wm*=.5
    h=np.sqrt(np.asarray(x))[:,None,None]
    w=np.sqrt(z)[None,:,None]
    mu=mu[None,None,:]
    sp=(w*w+h*h+2*w*h*mu)/2
    sm=(w*w+h*h-2*w*h*mu)/2
    Lp=np.array([eval_genlaguerre(i,1.5,sp) for i in range(N+1)])
    Lm=np.array([eval_genlaguerre(i,1.5,sm) for i in range(N+1)])
    normv=np.exp(gammaln(np.arange(N+1)+2.5)-gammaln(np.arange(N+1)+1))*2/(3*np.sqrt(np.pi))
    Lp/=np.sqrt(normv)[:,None,None,None]; Lm/=np.sqrt(normv)[:,None,None,None]
    dfz=(w+h*mu)/np.sqrt(2)*Lp[:N]
    dft=h*np.sqrt(1-mu*mu)/np.sqrt(2)*Lp[:N]
    htz=((w+h*mu)*Lp[1:]+(w-h*mu)*Lm[1:])/np.sqrt(2)
    htt=h*np.sqrt(1-mu*mu)/np.sqrt(2)*(Lp[1:]-Lm[1:])
    Pp=np.array([eval_genlaguerre(i,2.5,sp) for i in range(N)])
    Pm=np.array([eval_genlaguerre(i,2.5,sm) for i in range(N)])
    norms=np.exp(gammaln(np.arange(N)+3.5)-gammaln(np.arange(N)+1))*2/(15*np.sqrt(np.pi))
    Pp/=np.sqrt(norms)[:,None,None,None]; Pm/=np.sqrt(norms)[:,None,None,None]
    sh0=((1.5*(w+h*mu)**2-sp)*Pp+(1.5*(w-h*mu)**2-sm)*Pm)/np.sqrt(6)
    sh1=h*np.sqrt(1-mu*mu)/np.sqrt(2)*((w+h*mu)*Pp-(w-h*mu)*Pm)
    sh2=h*h*(1-mu*mu)/(2*np.sqrt(2))*(Pp+Pm)
    out=np.zeros((3,len(x),N+2,N,N))
    def project(v,l,m):
        p=lpmv(m,l,mu.ravel())*wm
        v=np.einsum('ixzk,k->xzi',v,p)
        fac=(2*l+1)*np.exp(gammaln(l-m+1)-gammaln(l+m+1))
        return fac*np.einsum('xzi,z,xzj->xij',v,wz,v,optimize=True)
    for l in range(1,N+2):
        out[0,:,l]=(project(dfz,l,0)+project(dft,l,1))/3
        if l%2==0:
            out[1,:,l]=(project(htz,l,0)+project(htt,l,1))/6
            out[2,:,l]=(project(sh0,l,0)+project(sh1,l,1)+project(sh2,l,2))/20
    return out

def transport(x,weights,Q,T,N=10):
    K=kernels(x,N)
    B=np.einsum('x,pxlij,xl->pij',weights*4*np.sqrt(T/np.pi),K,Q,optimize=True)
    invs=[]
    for b in B:
        invs.append(np.linalg.solve(b,np.eye(N)[:,0])[0])
    return np.array([T*invs[2],2.5*T*invs[1],T*invs[0]])


import numpy as np
from scipy.optimize import brentq
from scipy.special import roots_legendre
import time

class Scatter:
    def __init__(self,A,L=14,h=.05,ng=32):
        self.A=A;self.d=1-A;self.k=A/self.d;self.L=L
        k=self.k
        self.sp=brentq(lambda s:4*s**7+7*k*s**6-20*s-26*k,1,2)
        self.ec=self.W(self.sp)
        v=np.arange(-3.5,3.5+h/2,h)
        y=np.pi/2*np.sinh(v)
        # Accurate distances from either endpoint.
        self.dt=1/(1+np.exp(2*y))
        self.t=1/(1+np.exp(-2*y))
        self.wt=h*np.pi*np.cosh(v)*self.t*self.dt
        good=(self.dt>1e-16)&(self.t>1e-16)
        self.dt=self.dt[good];self.t=self.t[good];self.wt=self.wt[good]
        self.g,self.gw=roots_legendre(ng)
    def V(self,s):
        p=s**-6;return 4*p*(p-1)
    def W(self,s):
        return -20*s**-12+8*s**-6+self.k*(12*s**-7-24*s**-13)
    def B(self,s,E):
        return (self.A+self.d*s)**2*(1-self.V(s)/E)
    def deriv(self,s,E):
        return 2*self.d*(self.A+self.d*s)*(1-self.W(s)/E)
    def angles(self,s,E,so=None):
        s=np.asarray(s);r=self.A+self.d*s
        p=s**-6;vv=4*p*(p-1);beta=1-vv/E
        def phi(t,dt,wt):
            # t and 1-t supplied independently for endpoint accuracy.
            z= -dt*r[:,None]/(r[:,None]-self.A*t)
            with np.errstate(divide="ignore"):
                logk=np.log1p(np.maximum(z,-1))
            F=dt*(1+t)*beta[:,None]+4/E*(p[:,None]*np.expm1(6*logk)-p[:,None]**2*np.expm1(12*logk))
            return np.sum(wt/np.sqrt(np.maximum(F,1e-300)),axis=1)
        if so is None:
            val=phi(self.t,self.dt,self.wt)
        else:
            tc=r/(self.A+self.d*so)
            # Called only on inner branch.
            val=phi(tc[:,None]*self.t,1-tc[:,None]+tc[:,None]*self.dt,tc[:,None]*self.wt)
            val+=phi(tc[:,None]+(1-tc[:,None])*self.t,(1-tc[:,None])*self.dt,(1-tc[:,None])*self.wt)
        return np.cos(np.pi-2*np.sqrt(np.maximum(beta,0))*val)
    def integrand(self,s,E,so=None):
        if so is None and self.ec<=E<1.2*self.ec:
            inside=s<self.sp
            c=np.empty(len(s))
            c[inside]=self.angles(s[inside],E,self.sp)
            c[~inside]=self.angles(s[~inside],E)
        else:
            c=self.angles(s,E,so)
        out=np.empty((len(s),self.L+1));out[:,0]=0
        prev=np.ones(len(s));cur=c
        for l in range(1,self.L+1):
            out[:,l]=1-cur
            prev,cur=cur,((2*l+1)*c*cur-l*prev)/(l+1)
        return out*self.deriv(s,E)[:,None]*np.pi
    def cross(self,E,step=.5):
        rz=(2/(1+np.sqrt(1+E)))**(1/6)
        rmax=40*max(1,E**(-1/6))
        smax=(rmax-self.A)/self.d
        # Fixed composite Gaussian rule, with logarithmic concentration at orbiting.
        res=np.zeros(self.L+1)
        def integ(lo,hi,fun):
            nonlocal res
            n=int(np.ceil((hi-lo)/step));edges=np.linspace(lo,hi,n+1)
            half=np.diff(edges)/2;mid=(edges[1:]+edges[:-1])/2
            x=(mid[:,None]+half[:,None]*self.g).ravel()
            w=(half[:,None]*self.gw).ravel()
            for j in range(0,len(x),256):
                vals=fun(x[j:j+256])
                res+=np.einsum('x,xl->l',w[j:j+256],vals)
        if E<self.ec:
            si=brentq(lambda s:self.W(s)-E,rz,self.sp,xtol=1e-14,rtol=1e-14)
            so=brentq(lambda s:self.W(s)-E,self.sp,max(2,(16*(1+self.k)/E)**(1/6)),xtol=1e-14,rtol=1e-14)
            bc=self.B(so,E)
            sr=brentq(lambda s:self.B(s,E)-bc,rz,si,xtol=1e-14,rtol=1e-14)
            length=sr-rz
            integ(-23,0,lambda z:self.integrand(sr-length*np.exp(z),E,so)* (length*np.exp(z))[:,None])
            scale=so
            integ(-23,np.log((smax-so)/scale),lambda z:self.integrand(so+scale*np.exp(z),E)* (scale*np.exp(z))[:,None])
        else:
            # Geometric radial panels, split around the marginal orbit if close to its energy.
            if E<1.1*self.ec:
                leng=self.sp-rz
                integ(-23,0,lambda z:self.integrand(self.sp-leng*np.exp(z),E)*(leng*np.exp(z))[:,None])
                integ(-23,np.log((smax-self.sp)/self.sp),lambda z:self.integrand(self.sp+self.sp*np.exp(z),E)*(self.sp*np.exp(z))[:,None])
            else:
                integ(np.log(rz),np.log(smax),lambda z:self.integrand(np.exp(z),E)*np.exp(z)[:,None])
        return res


import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from scipy.special import roots_legendre
import time,sys

def calculate(A,T,N=16,order=18,step=.3,h=.035,ng=48,bstep=.25,verbose=False):
    sc=Scatter(A,L=N+1,h=h,ng=ng)
    g,gw=roots_legendre(order)
    bounds=[-9,np.log(120)]
    crit=np.log(sc.ec/T)
    if bounds[0]<crit<bounds[-1]:bounds.insert(1,crit)
    xs=[];ws=[]
    for lo,hi in zip(bounds[:-1],bounds[1:]):
        edges=np.linspace(lo,hi,int(np.ceil((hi-lo)/step))+1)
        mid=(edges[:-1]+edges[1:])/2;half=np.diff(edges)/2
        u=(mid[:,None]+half[:,None]*g).ravel()
        x=np.exp(u);xs.extend(x);ws.extend((half[:,None]*gw).ravel()*x*x*np.exp(-x))
    x=np.array(xs);weights=np.array(ws)
    t=time.time()
    Q=np.array([sc.cross(float(e),step=bstep) for e in T*x])
    if verbose:print('cross',len(x),time.time()-t,flush=True)
    B=np.zeros((3,N,N))
    for i in range(0,len(x),64):
        xx=x[i:i+64];ww=weights[i:i+64];qq=Q[i:i+64]
        K=kernels(xx,N)
        B+=np.einsum('x,pxlij,xl->pij',ww*4*np.sqrt(T/np.pi),K,qq,optimize=True)
    if verbose:print('brackets',time.time()-t,flush=True)
    outs=[]
    for n in range(1,N+1):
        invs=[np.linalg.solve(b[:n,:n],np.eye(n)[:,0])[0] for b in B]
        out=np.array([T*invs[2],2.5*T*invs[1],T*invs[0]])
        outs.append(out)
        if verbose:print(n,out,flush=True)
    return outs[-1],B,x,weights,Q


if __name__ == '__main__':
    A, T = map(float, sys.argv[1:3])
    values, *_ = calculate(A, T)
    print(json.dumps(dict(zip(
        ('viscosity', 'thermal_conductivity', 'self_diffusion'),
        map(float, values))), allow_nan=False, separators=(',', ':')))
