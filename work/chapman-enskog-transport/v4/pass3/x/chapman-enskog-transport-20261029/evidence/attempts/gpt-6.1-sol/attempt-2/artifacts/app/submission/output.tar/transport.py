#!/usr/bin/env python3
"""Classical dilute-gas transport for the spherical-core Kihara potential.

Units: sigma = epsilon = m = k_B = 1.
The linearized collision equations are solved by a converged Sonine-Galerkin
method, not by the first-Sonine transport formulas.  Angular scattering is
computed from the potential itself, including both sides of the orbiting
barrier.  The speed and angular integrations form the full collision brackets.

With x = v/sqrt(2T), write x1=C+q, x2=C-q.  C has component variance 1/4
and z=2*q.q is the relative collision energy divided by T.  The vector basis
is x L_k^(3/2)(x.x); the tensor basis is its traceless rank-two counterpart
with L_k^(5/2).  Gaussian averages over C are evaluated analytically using
the Laguerre generating function.  Their Legendre coefficients provide the
collision kernels.  Conserved momentum is projected out of the heat equation.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
from scipy.special import eval_genlaguerre
from math import comb, factorial, pi

def cmul(a):
    b=np.zeros_like(a)
    for l in range(a.shape[-1]-1):
        b[...,l+1]+=a[...,l]*(l+1)/(2*l+1)
    for l in range(1,a.shape[-1]):
        b[...,l-1]+=a[...,l]*l/(2*l+1)
    return b

def base(z,N,nu,L):
    z=np.asarray(z)
    out=np.zeros((len(z),N,N,L))
    for i in range(N):
        for j in range(N):
            for k in range(min(i,j)+1):
                p=i+j-2*k
                v=(z/2)**k/factorial(k)*comb(p,i-k)/2**p*eval_genlaguerre(p,nu+k-1,z)
                for l in range(min(k,L-1)+1):
                    c=(2*l+1)*2**k*factorial(k)**2/(factorial(k-l)*factorial(k+l+1))
                    out[:,i,j,l]+=c*v
    return out

R={(0,0):(0,4),(1,0):(-2,-2),(0,1):(-2,-2),(1,1):(2,2)}
def polymul(a,b):
    out={}
    for (i,j),v in a.items():
        for (k,l),w in b.items():
            key=i+k,j+l
            val=np.convolve(v,w)
            if key not in out: out[key]=np.zeros(len(val))
            if len(out[key])<len(val): out[key]=np.pad(out[key],(0,len(val)-len(out[key])))
            out[key][:len(val)]+=val
    return out

def mult(f,poly):
    out=np.zeros_like(f)
    N=f.shape[1]
    for (i,j),coef in poly.items():
        if i>=N or j>=N: continue
        v=f[:,:N-i,:N-j,:]
        for c in coef:
            if c: out[:,i:,j:,:]+=c*v
            v=cmul(v)
    return out

def kernels(z,N):
    z=np.asarray(z); L=N+2
    f25=base(z,N,2.5,L)
    f35=base(z,N,3.5,L)
    f45=base(z,N,4.5,L)
    f55=base(z,N,5.5,L)
    zz=z[:,None,None,None]
    vec=.75*f25+zz/8*mult(f35,R)
    ten=zz**2/96*mult(f55,polymul(R,R))-zz**2/12*mult(f35,{(0,0):(1,0,-1)})+5*zz/24*mult(f45,R)+5/8*f35
    return vec,ten

def solve(T,z,weights,Q,N=9):
    vec,ten=kernels(z,N)
    w=weights*4*np.sqrt(T/pi)
    even=np.arange(Q.shape[1])%2==0
    even[0]=False
    allq=Q.copy();allq[:,0]=0
    qe=Q*even
    # Tagged-particle bracket: 1/2 of the squared single-particle jump.
    bd=np.einsum('zijl,zl,z->ij',vec,allq,w)/3
    # Identical-particle brackets: 1/4 of the squared pair jump.
    bh=np.einsum('zijl,zl,z->ij',vec,qe,w)*2/3
    bv=np.einsum('zijl,zl,z->ij',ten,qe,w)/5
    results=[]
    for n in range(2,N+1):
        def inv_entry(b,k,start=0):
            b=b[start:n,start:n];k-=start
            s=np.sqrt(np.maximum(np.diag(b),1e-300))
            mat=b/s[:,None]/s[None,:]
            rhs=np.zeros(n-start);rhs[k]=1/s[k]
            return np.linalg.solve(mat,rhs)[k]/s[k]
        results.append((T/4*inv_entry(bv,0),25*T/8*inv_entry(bh,1,1),T/2*inv_entry(bd,0)))
    return np.array(results)


import numpy as np
from scipy.special import roots_legendre
from scipy.optimize import brentq
from math import pi
from functools import lru_cache

@lru_cache(None)
def gauss(n):
    x,w=roots_legendre(n)
    return (x+1)/2,w/2

class Scatter:
    def __init__(self,a,L=11,tol=1e-7):
        self.a=a;self.d=1-a;self.L=L;self.tol=tol
        ad=a/self.d
        self.um=brentq(lambda u:4-20*u**6+7*ad*u-26*ad*u**7,0,1,xtol=1e-15)
        self.ec=self.H(self.um)
        self.calls=0;self.anglecalls=0
    def H(self,u):
        ad=self.a/self.d
        return 8*u**6-20*u**12+12*ad*u**7-24*ad*u**13
    def Hp(self,u):
        ad=self.a/self.d
        return 48*u**5-240*u**11+84*ad*u**6-312*ad*u**12
    def B(self,u,E):
        return (self.a+self.d/u)**2*(1+4*(u**6-u**12)/E)
    def minusBp(self,u,E):
        return 2*self.d*(self.a+self.d/u)/u**2*(1-self.H(u)/E)
    def getH(self,x,u,E):
        # Factor the exact turning-point zero before evaluating the radicand.
        ar=self.a*u
        c6=4*u**6/E;c12=4*u**12/E
        ss=np.ones_like(x)
        sums={}
        for k in range(1,12):
            ss=ss*x+1
            if k in (3,4,5,9,10,11): sums[k]=ss.copy()
        return self.d**2*(1+x)+2*self.d*ar*x+x*x*(c12*(self.d**2*sums[9]+2*self.d*ar*sums[10]+ar*ar*sums[11])-c6*(self.d**2*sums[3]+2*self.d*ar*sums[4]+ar*ar*sums[5]))
    def theta_rule(self,u,E,uc,bc,n,inner):
        self.anglecalls+=len(u)
        q,w=gauss(n);q=q[None,:];w=w[None,:]
        ur=u[:,None];bsq=np.maximum(0,self.B(ur,E));b=np.sqrt(bsq)
        if inner and uc is not None:
            rc=self.a+self.d/uc
            beta=self.d/(uc**2*rc)*self.Hp(uc)/E
            delta=np.maximum((bc-bsq)/rc**2,1e-30)
            h=np.sqrt(delta/beta)
            # Left of the former barrier maximum.
            S=np.arcsinh(uc/h)
            s=S*q
            v=uc-h*np.sinh(s);x=v/ur
            F=(1-x)*self.getH(x,ur,E)
            jac=h*np.cosh(s)*S
            left=np.sum(w*jac/((self.d+self.a*v)*np.sqrt(np.maximum(F,1e-300))),axis=1)
            # Right side, with the turning-point square root removed as well.
            S=np.arcsinh((ur-uc)/h)
            s=S*(1-q*q)
            gap=2*h*np.cosh((S+s)/2)*np.sinh(S*q*q/2)
            v=ur-gap;x=v/ur
            F=gap/ur*self.getH(x,ur,E)
            jac=2*S*q*h*np.cosh(s)
            right=np.sum(w*jac/((self.d+self.a*v)*np.sqrt(np.maximum(F,1e-300))),axis=1)
            return (b[:,0]*self.d)*(left+right)
        H1=self.getH(np.ones_like(ur),ur,E)
        Hnear=self.getH(np.full_like(ur,1-1e-5),ur,E)
        slope=np.abs((Hnear-H1)/1e-5)
        h=np.sqrt(np.maximum(H1,1e-28)/(np.maximum(H1,1e-28)+slope))
        S=np.arcsinh(1/h)
        s=S*q;t=h*np.sinh(s)
        x=1-t*t
        H=self.getH(x,ur,E)
        jac=h*np.cosh(s)*S
        v=2*b*self.d*ur*np.sum(w*jac/((self.d+self.a*ur*x)*np.sqrt(np.maximum(H,1e-300))),axis=1)[:,None]
        return v[:,0]
    def theta(self,u,E,uc,bc,inner):
        old=self.theta_rule(u,E,uc,bc,24,inner)
        new=self.theta_rule(u,E,uc,bc,48,inner)
        err=np.abs(new-old)
        todo=np.where(err>2e-9)[0]
        n=96
        while len(todo) and n<=1536:
            v=self.theta_rule(u[todo],E,uc,bc,n,inner)
            err=np.abs(v-new[todo])
            new[todo]=v
            todo=todo[err>2e-9]
            n*=2
        return new
    def integrand(self,x,E,uc,bc,ui,u0,inner):
        if uc is None:
            u=u0*x;du=np.full_like(x,u0)
        elif inner:
            u=ui+(u0-ui)*x**3;du=3*(u0-ui)*x*x
        else:
            u=uc*(1-(1-x)**2);du=2*uc*(1-x)
        th=self.theta(u,E,uc,bc,inner)
        delta=2*np.cos(th)**2
        out=np.zeros((len(x),self.L));out[:,1]=delta
        for l in range(1,self.L-1):
            out[:,l+1]=((2*l+1)*(delta+(1-delta)*out[:,l])-l*out[:,l-1])/(l+1)
        return out*(pi*du*self.minusBp(u,E))[:,None]
    def __call__(self,E,n=96):
        self.calls+=1
        u0=((1+np.sqrt(1+E))/2)**(1/6)
        if E<self.ec*(1-1e-12):
            uc=brentq(lambda u:self.H(u)-E,0,self.um,xtol=1e-15)
            bc=self.B(uc,E)
            uh=brentq(lambda u:self.H(u)-E,self.um,u0,xtol=1e-15)
            ui=brentq(lambda u:self.B(u,E)-bc,uh,u0,xtol=1e-15)
            branches=[False,True]
        else:
            uc=bc=ui=None;branches=[False]
        def rule(n):
            x,w=gauss(n)
            return sum(w@self.integrand(x,E,uc,bc,ui,u0,inner) for inner in branches)
        old=rule(n)
        new=rule(n*2)
        while np.max(np.abs(new[1:]-old[1:])/np.maximum(np.abs(new[1:]),1e-20))>self.tol and n<1536:
            n*=2;old=new;new=rule(n*2)
        return new


def calculate(a,T,n=32,N=16,width=.75,tol=3e-8):
    sc=Scatter(a,N+2,tol)
    lo=np.log(1e-5);hi=np.log(100.)
    edges=list(np.linspace(lo,hi,int(np.ceil((hi-lo)/width))+1))
    crit=np.log(sc.ec/T)
    if lo<crit<hi:
        edges.append(crit)
        # Resolve the weak nonanalyticity at the orbiting critical energy.
        for delta in [.02,.1]:
            if lo<crit-delta<hi: edges.append(crit-delta)
            if lo<crit+delta<hi: edges.append(crit+delta)
    edges=np.unique(edges)
    x,w=gauss(n)
    z=[];weights=[]
    for l,r in zip(edges[:-1],edges[1:]):
        zz=np.exp(l+(r-l)*x)
        z.extend(zz);weights.extend(w*(r-l)*zz**2*np.exp(-zz))
    z=np.array(z);weights=np.array(weights)
    Q=[]
    for i,zz in enumerate(z):
        Q.append(sc(T*zz))
    Q=np.array(Q)
    values=solve(T,z,weights,Q,N)
    return values

if __name__ == '__main__':
    import sys, json
    A,T=map(float,sys.argv[1:3])
    result=calculate(A,T)[-1]
    print(json.dumps(dict(zip(('viscosity','thermal_conductivity','self_diffusion'),map(float,result))),allow_nan=False,separators=(',',':')))
