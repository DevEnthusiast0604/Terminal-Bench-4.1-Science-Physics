#!/usr/bin/env python3
"""Classical dilute-gas transport for a spherical-core Kihara potential.

Units: sigma = epsilon = molecular mass = Boltzmann constant = 1.
The linearized collision equations are solved by converged Galerkin
inversion, not by a first-Sonine transport formula.

Let c = v/sqrt(2*T), R=(c1+c2)/2, h=(c1-c2)/2, x=2*h**2.
R has Gaussian variance 1/4; x has gamma density of index 1/2.
For each collision energy E=T*x we compute
  Q_l(E) = pi * integral_0^infinity [1-P_l(cos(chi))] d(b**2).
Angular harmonic projections of the polynomial trial functions give
positive collision-bracket weights. Integration over R and its angle
is exact Gaussian quadrature for the chosen polynomial space.
Diffusion uses c L_n^(3/2)(c**2), n>=0; heat uses the same vectors
with n>=1; stress uses (cc-I*c**2/3) L_n^(5/2)(c**2).
The scalar n=0 vector invariant is thus excluded from the heat equation.
The tagged-particle bracket has prefactor 4*sqrt(T/pi); the two
single-component brackets have prefactor 2*sqrt(T/pi), using an
energy integration weight x*exp(-x). Source constants are respectively
3/2, 75/8, and 5/2. Inverse (0,0) matrix elements times T and the
source constants are the requested reduced transport coefficients.

Turning-point quadrature uses r=r0/(1-z**2), removing its square-root
endpoint singularity. Near orbiting, a split sinh map resolves the
radial minimum. Impact-parameter integration is split at the critical
orbit and uses quartic endpoint maps. Excluded endpoint neighborhoods
have relative b**2 measure about 1.5e-8; their bounded contribution
is immaterial at the output tolerance. The remote tail is likewise
negligible for this r**-6 potential.
"""
import os
# Avoid excessive native-library threading on the two-CPU worker.
for _key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_key] = '1'
import sys, json
import numpy as np
from scipy.special import roots_legendre
from scipy.optimize import minimize_scalar, brentq
from functools import lru_cache

@lru_cache(None)
def gauss(n):
    x,w=roots_legendre(n)
    return (x+1)/2,w/2

class Scattering:
    def __init__(self,a):
        self.a=a; self.d=1-a
        self.tp=np.exp(minimize_scalar(lambda s:-self.F(np.exp(s)),bounds=(0,3),method='bounded',options={'xatol':1e-14}).x)
        self.rp=a+self.d*self.tp
        self.ec=self.F(self.tp)
    def V(self,t):
        p=t**-6
        return 4*p*(p-1)
    def F(self,t):
        p=t**-6
        return 4*p*(2-5*p)+12*self.a/self.d/t*p*(1-2*p)
    def cross(self,E,L=13,nb=160,nr=80):
        a,d=self.a,self.d
        th=(2/(1+np.sqrt(1+E)))**(1/6); rh=a+d*th
        def B(r):
            return r*r*(1-self.V((r-a)/d)/E)
        orbit=E<self.ec
        t,w=gauss(nb)
        tin=t*(1-np.exp(-18/4)); win=w*(1-np.exp(-18/4))
        tout=t*(100**.5/(1+100**.5)); wout=w*(100**.5/(1+100**.5))
        if orbit:
            ti=brentq(lambda u:self.F(u)-E,th,self.tp,xtol=1e-14)
            to=brentq(lambda u:self.F(u)-E,self.tp,max(3*self.tp,(32*(1+a/d)/E)**(1/6)),xtol=1e-14)
            ro=a+d*to; ri=a+d*ti
            qc=B(ro)
            qi=qc*(1-(1-tin)**4); wi=4*qc*(1-tin)**3*win
            qo=qc+qc*(1.5e-8+(tout/(1-tout))**4); wo=4*qc*tout**3/(1-tout)**5*wout
            q=np.r_[qi,qo]; wq=np.r_[wi,wo]
            lo=np.r_[np.full(nb,rh),np.full(nb,ro)]
            hi=np.r_[np.full(nb,ri),np.maximum(2*ro, np.sqrt(qo)+rh)]
            rs=ro
        else:
            rs=self.rp
            if E<3*self.ec:
                qc=B(rs)
                qi=qc*(1-(1-tin)**4); wi=4*qc*(1-tin)**3*win
                qo=qc+qc*(1.5e-8+(tout/(1-tout))**4); wo=4*qc*tout**3/(1-tout)**5*wout
                q=np.r_[qi,qo]; wq=np.r_[wi,wo]
            else:
                tt=t*100/101; ww=w*100/101
                q=rh*rh*(tt/(1-tt))**2; wq=2*rh*rh*tt/(1-tt)**3*ww
            lo=np.full(len(q),rh); hi=np.maximum(2*rs,np.sqrt(q)+rh)
        for _ in range(55):
            mid=(lo+hi)/2
            hit=B(mid)>q
            hi=np.where(hit,mid,hi); lo=np.where(hit,lo,mid)
        r0=(lo+hi)/2
        p0=((r0-a)/d)**-6
        zc=np.sqrt(np.maximum(0,1-r0/rs))
        small=np.maximum(1e-16,1-q/rs**2-self.V((rs-a)/d)/E)
        # Split at the potentially shallow radial minimum; use sinh maps on both sides.
        scale=np.sqrt(small)*.15
        slope=np.maximum(1e-16,2*(1-self.F((r0-a)/d)/E))
        scale=np.where(r0<rs,scale,np.minimum(1,np.sqrt(slope)*.25))
        v,wv=gauss(nr)
        def segment(length,sign):
            kap=np.arcsinh(length/scale)
            zz=zc[:,None]+sign*scale[:,None]*np.sinh(kap[:,None]*v)
            jac=scale[:,None]*kap[:,None]*np.cosh(kap[:,None]*v)
            zz2=zz*zz; u=1-zz2
            lu=np.log1p(-zz2)
            lw=lu-np.log1p((a/(r0-a))[:,None]*zz2)
            f=zz2*(2-zz2)+4/E*u*u*(p0[:,None]*np.expm1(6*lw-2*lu)-p0[:,None]**2*np.expm1(12*lw-2*lu))
            f=np.where(length[:,None]==0,1,f)
            if np.any(f<=0):
                raise RuntimeError(('radicand',E,float(np.min(f))))
            return np.sum(wv*jac*zz/np.sqrt(f),axis=1)
        integral=segment(zc,-1)+segment(1-zc,1)
        chi=np.pi-4*np.sqrt(q)/r0*integral
        dc=2*np.sin(chi/2)**2
        W=np.zeros((len(q),L+1)); W[:,1]=dc
        for l in range(2,L+1):
            W[:,l]=(2*l-1)/l*(dc+(1-dc)*W[:,l-1])-(l-1)/l*W[:,l-2]
        return np.pi*np.einsum('b,bl->l',wq,W)


import numpy as np
from scipy.special import roots_genlaguerre, roots_legendre, eval_genlaguerre, lpmv, gammaln

def weights(x,N=10):
    y,wy=roots_genlaguerre(N+2,.5); wy*=2/np.sqrt(np.pi)
    z,wz=roots_legendre(N+3); wz*=.5
    R=np.sqrt(y/2)[None,:,None]; h=np.sqrt(x/2)[:,None,None]
    z=z[None,None,:]; p=np.sqrt(1-z*z)
    sp=R*R+h*h+2*R*h*z; sm=R*R+h*h-2*R*h*z
    Lmax=N+1
    projs=[]
    for m in range(3):
        P=np.zeros((Lmax+1,z.size))
        for l in range(m,Lmax+1):
            P[l]=lpmv(m,l,z.ravel())*np.sqrt((2*l+1)*np.exp(gammaln(l-m+1)-gammaln(l+m+1)))*wz
        projs.append(P)
    result=[]
    for kind in ['d','h','v']:
        alpha=2.5 if kind=='v' else 1.5
        ns=np.arange(N)+(1 if kind=='h' else 0)
        lp=np.array([eval_genlaguerre(int(n),alpha,sp) for n in ns])
        lm=np.array([eval_genlaguerre(int(n),alpha,sm) for n in ns])
        if kind=='d':
            fs=[(R+h*z)*lp,h*p*lp]
        elif kind=='h':
            fs=[(R+h*z)*lp+(R-h*z)*lm,h*p*(lp-lm)]
        else:
            fs=[np.sqrt(1.5)*(((R+h*z)**2-sp/3)*lp+((R-h*z)**2-sm/3)*lm),np.sqrt(2)*h*p*((R+h*z)*lp-(R-h*z)*lm),h*h*p*p/np.sqrt(2)*(lp+lm)]
        B=np.zeros((len(x),Lmax+1,N,N))
        for m,f in enumerate(fs):
            aa=np.einsum('nxrz,lz->xlrn',f,projs[m],optimize=True)
            B+=np.einsum('xlri,xlrj,r->xlij',aa,aa,wy,optimize=True)
        B[:,0]=0
        if kind!='d': B[:,1::2]=0
        result.append(B)
    return result


def grid(T,s,n=24):
    b=np.array([1e-4,1e-3,.01,.05,.1,.2,.4,.8,1.5,3,5,8,12,18,26,36,48,64,84,110,140.])
    xc=s.ec/T
    b=np.unique(np.r_[b,xc*np.array([.5,.8,.95,.99,1,1.01,1.05,1.2,1.5,3])]); b=b[(b>=0)&(b<=140)]
    z,w=roots_legendre(n)
    x=((b[1:]+b[:-1])[:,None]/2+(b[1:]-b[:-1])[:,None]/2*z).ravel()
    w=((b[1:]-b[:-1])[:,None]/2*w).ravel()*x*np.exp(-x)
    return x,w


def assemble(x,w,Q,T,N):
    matrices=[np.zeros((N,N)) for _ in range(3)]
    for start in range(0,len(x),48):
        sl=slice(start,start+48)
        B=weights(x[sl],N)
        for j,bb in enumerate(B):
            matrices[j]+=np.einsum('x,xl,xlij->ij',w[sl],Q[sl,:N+2],bb,optimize=True)
    values=[]; errors=[]
    for mat,pref,source in zip(matrices,[4,2,2],[1.5,75/8,2.5]):
        mat*=pref*np.sqrt(T/np.pi)
        d=1/np.sqrt(np.diag(mat)); mat=mat*d[:,None]*d[None,:]
        val=source*T*np.linalg.solve(mat,np.eye(N)[0])[0]*d[0]**2
        n=N-4
        old=source*T*np.linalg.solve(mat[:n,:n],np.eye(n)[0])[0]*d[0]**2
        values.append(float(val)); errors.append(abs(val/old-1))
    return values,max(errors)

def transport(A,T):
    s=Scattering(A)
    x,w=grid(T,s,40)
    Q=np.array([s.cross(T*xx,25,640,192) for xx in x])
    vals,err=assemble(x,w,Q,T,18)
    if err>1e-7:
        vals,err=assemble(x,w,Q,T,24)
    return dict(viscosity=vals[2],thermal_conductivity=vals[1],self_diffusion=vals[0])

if __name__=='__main__':
    A,T=map(float,sys.argv[1:3])
    print(json.dumps(transport(A,T),allow_nan=False,separators=(',',':')))
